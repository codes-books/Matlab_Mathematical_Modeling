%���ںϲ�
clc,clear;
load jlIO.mat
n0=size(OID);
jlIzxjl(1,1)=min(OID(n0(1,1),1:n0(1,2)-1));
for i=1:n0(1,2)-1
    if jlIzxjl(1,1)==OID(n0(1,1),i);
       jlIzxjl(1,2)=i;
    end
end



 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')