function varargout = ysw2(varargin)
% YSW2 MATLAB code for ysw2.fig
%      YSW2, by itself, creates a new YSW2 or raises the existing
%      singleton*.
%
%      H = YSW2 returns the handle to a new YSW2 or the handle to
%      the existing singleton*.
%
%      YSW2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in YSW2.M with the given input arguments.
%
%      YSW2('Property','Value',...) creates a new YSW2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ysw2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ysw2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ysw2

% Last Modified by GUIDE v2.5 23-Sep-2013 19:13:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ysw2_OpeningFcn, ...
                   'gui_OutputFcn',  @ysw2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ysw2 is made visible.
function ysw2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ysw2 (see VARARGIN)

% Choose default command line output for ysw2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ysw2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ysw2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit41_Callback(hObject, eventdata, handles)
% hObject    handle to edit41 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit41 as text
%        str2double(get(hObject,'String')) returns contents of edit41 as a double


% --- Executes during object creation, after setting all properties.
function edit41_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit41 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit42_Callback(hObject, eventdata, handles)
% hObject    handle to edit42 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit42 as text
%        str2double(get(hObject,'String')) returns contents of edit42 as a double


% --- Executes during object creation, after setting all properties.
function edit42_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit42 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit43_Callback(hObject, eventdata, handles)
% hObject    handle to edit43 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit43 as text
%        str2double(get(hObject,'String')) returns contents of edit43 as a double


% --- Executes during object creation, after setting all properties.
function edit43_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit43 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit44_Callback(hObject, eventdata, handles)
% hObject    handle to edit44 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit44 as text
%        str2double(get(hObject,'String')) returns contents of edit44 as a double


% --- Executes during object creation, after setting all properties.
function edit44_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit44 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit45_Callback(hObject, eventdata, handles)
% hObject    handle to edit45 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit45 as text
%        str2double(get(hObject,'String')) returns contents of edit45 as a double


% --- Executes during object creation, after setting all properties.
function edit45_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit45 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit46_Callback(hObject, eventdata, handles)
% hObject    handle to edit46 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit46 as text
%        str2double(get(hObject,'String')) returns contents of edit46 as a double


% --- Executes during object creation, after setting all properties.
function edit46_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit46 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit47_Callback(hObject, eventdata, handles)
% hObject    handle to edit47 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit47 as text
%        str2double(get(hObject,'String')) returns contents of edit47 as a double


% --- Executes during object creation, after setting all properties.
function edit47_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit47 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit48_Callback(hObject, eventdata, handles)
% hObject    handle to edit48 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit48 as text
%        str2double(get(hObject,'String')) returns contents of edit48 as a double


% --- Executes during object creation, after setting all properties.
function edit48_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit48 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit49_Callback(hObject, eventdata, handles)
% hObject    handle to edit49 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit49 as text
%        str2double(get(hObject,'String')) returns contents of edit49 as a double


% --- Executes during object creation, after setting all properties.
function edit49_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit49 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit50_Callback(hObject, eventdata, handles)
% hObject    handle to edit50 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit50 as text
%        str2double(get(hObject,'String')) returns contents of edit50 as a double


% --- Executes during object creation, after setting all properties.
function edit50_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit50 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit51_Callback(hObject, eventdata, handles)
% hObject    handle to edit51 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit51 as text
%        str2double(get(hObject,'String')) returns contents of edit51 as a double


% --- Executes during object creation, after setting all properties.
function edit51_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit51 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit52_Callback(hObject, eventdata, handles)
% hObject    handle to edit52 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit52 as text
%        str2double(get(hObject,'String')) returns contents of edit52 as a double


% --- Executes during object creation, after setting all properties.
function edit52_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit52 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit29_Callback(hObject, eventdata, handles)
% hObject    handle to edit29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit29 as text
%        str2double(get(hObject,'String')) returns contents of edit29 as a double


% --- Executes during object creation, after setting all properties.
function edit29_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit30_Callback(hObject, eventdata, handles)
% hObject    handle to edit30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit30 as text
%        str2double(get(hObject,'String')) returns contents of edit30 as a double


% --- Executes during object creation, after setting all properties.
function edit30_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit31_Callback(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit31 as text
%        str2double(get(hObject,'String')) returns contents of edit31 as a double


% --- Executes during object creation, after setting all properties.
function edit31_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit32_Callback(hObject, eventdata, handles)
% hObject    handle to edit32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit32 as text
%        str2double(get(hObject,'String')) returns contents of edit32 as a double


% --- Executes during object creation, after setting all properties.
function edit32_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit33_Callback(hObject, eventdata, handles)
% hObject    handle to edit33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit33 as text
%        str2double(get(hObject,'String')) returns contents of edit33 as a double


% --- Executes during object creation, after setting all properties.
function edit33_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit34_Callback(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit34 as text
%        str2double(get(hObject,'String')) returns contents of edit34 as a double


% --- Executes during object creation, after setting all properties.
function edit34_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit35_Callback(hObject, eventdata, handles)
% hObject    handle to edit35 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit35 as text
%        str2double(get(hObject,'String')) returns contents of edit35 as a double


% --- Executes during object creation, after setting all properties.
function edit35_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit35 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit36_Callback(hObject, eventdata, handles)
% hObject    handle to edit36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit36 as text
%        str2double(get(hObject,'String')) returns contents of edit36 as a double


% --- Executes during object creation, after setting all properties.
function edit36_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit37_Callback(hObject, eventdata, handles)
% hObject    handle to edit37 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit37 as text
%        str2double(get(hObject,'String')) returns contents of edit37 as a double


% --- Executes during object creation, after setting all properties.
function edit37_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit37 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit38_Callback(hObject, eventdata, handles)
% hObject    handle to edit38 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit38 as text
%        str2double(get(hObject,'String')) returns contents of edit38 as a double


% --- Executes during object creation, after setting all properties.
function edit38_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit38 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton14.
function pushbutton14_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
format short
warning off
global H Ma r Tind_f Tind_CDFS Tind_hcom Pind_f Pind_CDFS Pind_hcom Tin_f  Pin_f
global alpha nspeed zz tube_TP temp_f

load('D:\MATLAB Edit 2012B\ysw\20130920\data\fan.mat'); % ���ط����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\hcompressor.mat'); % ���ظ�ѹѹ�����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\CDFS.mat'); % ����CDFS(�����������ȼ�)�������ݡ���ԭʼ����

%% ����
Tin_f = tube_TP(1,1); %������������
Pin_f = tube_TP(1,2); %����������ѹ
%% ����
Tin_f = tube_TP(1,1); %������������
Pin_f = tube_TP(1,2); %����������ѹ
% �ڻ���ת��ncor�µ����Բ�ֵ ��ѹ�ȡ�Ч�ʡ���������
ncor_data_f = linear_interp(Tind_f,Tin_f,nspeed,fan);   % function ncor_data=linear_interp(Tind,Tin,n,data)
% ������� ��ѹ�ȡ�Ч�ʡ���������
com_ch_f = correct_com(ncor_data_f,alpha,0); % function com_ch=correct_com(data,alpha,flag)
% ������� ���¡���ѹ����������������
com_ch_f(1,:)=[]; % ��һ��Ϊ����ת��
%% ����ѹ�������ȳ�������
temp_f = Tout(com_ch_f,zz,Tin_f,Tind_f,Pin_f,Pind_f,0) % function temp=Tout(com_ch,zz,Tin,Tind,Pin,Pind,flag)
set(handles.edit31,'string',temp_f(1,1));
set(handles.edit30,'string',temp_f(1,2));
set(handles.edit29,'string',temp_f(1,3));
set(handles.edit32,'string',temp_f(1,4));
set(handles.edit33,'string',temp_f(1,5));


% --- Executes on button press in pushbutton15.
function pushbutton15_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
format short
warning off
global H Ma r Tind_f Tind_CDFS Tind_hcom Pind_f Pind_CDFS Pind_hcom Tin_f  Pin_f
global alpha nspeed zz tube_TP temp_f

load('D:\MATLAB Edit 2012B\ysw\20130920\data\fan.mat'); % ���ط����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\hcompressor.mat'); % ���ظ�ѹѹ�����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\CDFS.mat'); % ����CDFS(�����������ȼ�)�������ݡ���ԭʼ����

Tin_CDFS = temp_f(1,1); % CDFS��������,�����������
Pin_CDFS = temp_f(1,2); % CDFS������ѹ�����������ѹ
Win_CDFS = temp_f(1,3); % CDFS�������������������������
% �ڻ���ת��ncor�µ����Բ�ֵ ��ѹ�ȡ�Ч�ʡ���������
ncor_data_CDFS = linear_interp(Tind_CDFS,Tin_CDFS,nspeed,CDFS);   % function ncor_data=linear_interp(Tind,Tin,n,data)
% ������� ��ѹ�ȡ�Ч�ʡ���������
com_ch_CDFS = correct_com(ncor_data_CDFS,alpha,1); % function com_ch=correct_com(data,alpha,flag)
% CDFS ��� ���¡���ѹ����������������
com_ch_CDFS(1,:)=[]; % ��һ��Ϊ����ת��
%% ����ѹ����CDFS��������
temp_CDFS = Tout_W(com_ch_CDFS,Win_CDFS,zz,Tin_CDFS,Tind_CDFS,Pin_CDFS,Pind_CDFS,1) % function temp=Tout(com_ch,zz,Tin,Tind,Pin,Pind,flag)
set(handles.edit36,'string',temp_CDFS(1,1));
set(handles.edit35,'string',temp_CDFS(1,2));
set(handles.edit34,'string',temp_CDFS(1,3));
set(handles.edit37,'string',temp_CDFS(1,4));
set(handles.edit38,'string',temp_CDFS(1,5));


function edit39_Callback(hObject, eventdata, handles)
% hObject    handle to edit39 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit39 as text
%        str2double(get(hObject,'String')) returns contents of edit39 as a double


% --- Executes during object creation, after setting all properties.
function edit39_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit39 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit40_Callback(hObject, eventdata, handles)
% hObject    handle to edit40 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit40 as text
%        str2double(get(hObject,'String')) returns contents of edit40 as a double


% --- Executes during object creation, after setting all properties.
function edit40_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit40 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton16.
function pushbutton16_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
format short
warning off
global H Ma r Tind_f Tind_CDFS Tind_hcom Pind_f Pind_CDFS Pind_hcom Tin_f  Pin_f
global alpha nspeed zz tube_TP
alpha = get(handles.edit51,'string');      % ��Ҷ�Ƕ�
alpha=str2num(alpha);
nspeed = get(handles.edit52,'string');  % ���Ⱥ�CDFS������ת�ٶ�Ϊ0.95
nspeed =str2num(nspeed );
zz = get(handles.edit50,'string'); % ���Ⱥ�CDFS��ѹ�Ⱥ���ֵ��Ϊ 
zz=str2num(zz);

load('D:\MATLAB Edit 2012B\ysw\20130920\data\fan.mat'); % ���ط����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\hcompressor.mat'); % ���ظ�ѹѹ�����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\CDFS.mat'); % ����CDFS(�����������ȼ�)�������ݡ���ԭʼ����
% ����ѹ�����ܵ����¡���ѹ
tube_TP = tube(H,Ma,r)    % function tube_TP=tube(H,Ma,r)
set(handles.edit40,'string',tube_TP(1,1));
set(handles.edit39,'string',tube_TP(1,2));

% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
format short
warning off
global H Ma r Tind_f Tind_CDFS Tind_hcom Pind_f Pind_CDFS Pind_hcom Tin_f  Pin_f
H = get(handles.edit48,'string');%���и߶�
H=str2num(H);
Ma = get(handles.edit46,'string'); %����������
Ma=str2num(Ma);
r = get(handles.edit43,'string');  % ������ �������ָ��
r=str2num(r);

% �����¶ȸ���ֵ
Tind_f = get(handles.edit45,'string');
Tind_f=str2num(Tind_f);
Tind_CDFS=get(handles.edit44,'string');
Tind_CDFS=str2num(Tind_CDFS);
Tind_hcom=get(handles.edit47,'string');
Tind_hcom=str2num(Tind_hcom);
% ����ѹ������ֵ
Pind_f=get(handles.edit41,'string');
Pind_f=str2num(Pind_f);
Pind_CDFS=get(handles.edit49,'string');
Pind_CDFS=str2num(Pind_CDFS);
Pind_hcom=get(handles.edit42,'string');
Pind_hcom=str2num(Pind_hcom);

load('D:\MATLAB Edit 2012B\ysw\20130920\data\fan.mat'); % ���ط����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\hcompressor.mat'); % ���ظ�ѹѹ�����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\CDFS.mat'); % ����CDFS(�����������ȼ�)�������ݡ���ԭʼ����

% ����ѹ�����ܵ����¡���ѹ
tube_TP = tube(H,Ma,r);    % function tube_TP=tube(H,Ma,r)
Tin_f = tube_TP(1,1); %������������
Pin_f = tube_TP(1,2); %����������ѹ
%% ���� ��Ҷ�Ƕ�һ��
alpha = get(handles.edit51,'string'); ;      % ��Ҷ�Ƕ�
alpha=str2num(alpha);

zz = 0:0.01:1;       % ���Ⱥ�CDFS��ѹ�Ⱥ���ֵ��Ϊ0.5
nzz=size(zz);
nspeed =0:1.5/100:1.5;  % ���Ⱥ�CDFS������ת�ٶ�Ϊ0.95

for k=1:nzz(1,2)

    % �ڻ���ת��ncor�µ����Բ�ֵ ��ѹ�ȡ�Ч�ʡ���������
    ncor_data_f = linear_interp(Tind_f,Tin_f,nspeed(1,k),fan); % function ncor_data=linear_interp(Tind,Tin,n,data)
    % ������� ��ѹ�ȡ�Ч�ʡ���������
    com_ch_f = ncor_data_f; % correct_com(ncor_data_f,alpha,0); % function com_ch=correct_com(data,alpha,flag)
    com_ch_f(1,:)=[]; % ��һ��Ϊ����ת��

    ncom=size(com_ch_f);
    prc=com_ch_f(:,1); % ��ѹ��
    nc=com_ch_f(:,2);  % Ч��
    Wc=com_ch_f(:,3);  % ����

    for i=1:nzz(1,2)
        pr(i,1)=(max(prc)-min(prc))*zz(1,i)+min(prc);
        [a,b]=min(abs(prc-pr(i,1))); % a ��Сֵ��b ��Сֵ����λ��
        WC(k,i)=Wc(b,1); % ncor��zz�µ�prc,nc,Wc
    end
    
end
[nsg,zzg]=meshgrid(nspeed,zz);
axes(handles.axes1);
surf(nsg,zzg,WC);
view([59.5 32]);
xlabel('����ת��');ylabel('ѹ�Ⱥ���ֵzz');zlabel('����');
grid on;title('��Ҷ�Ƕ�һ����δ����'); axis tight



function edit27_Callback(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit27 as text
%        str2double(get(hObject,'String')) returns contents of edit27 as a double


% --- Executes during object creation, after setting all properties.
function edit27_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
format short
warning off
global H Ma r Tind_f Tind_CDFS Tind_hcom Pind_f Pind_CDFS Pind_hcom Tin_f  Pin_f
H = get(handles.edit48,'string');%���и߶�
H=str2num(H);
Ma = get(handles.edit46,'string'); %����������
Ma=str2num(Ma);
r = get(handles.edit43,'string');  % ������ �������ָ��
r=str2num(r);

% �����¶ȸ���ֵ
Tind_f = get(handles.edit45,'string');
Tind_f=str2num(Tind_f);
Tind_CDFS=get(handles.edit44,'string');
Tind_CDFS=str2num(Tind_CDFS);
Tind_hcom=get(handles.edit47,'string');
Tind_hcom=str2num(Tind_hcom);
% ����ѹ������ֵ
Pind_f=get(handles.edit41,'string');
Pind_f=str2num(Pind_f);
Pind_CDFS=get(handles.edit49,'string');
Pind_CDFS=str2num(Pind_CDFS);
Pind_hcom=get(handles.edit42,'string');
Pind_hcom=str2num(Pind_hcom);

load('D:\MATLAB Edit 2012B\ysw\20130920\data\fan.mat'); % ���ط����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\hcompressor.mat'); % ���ظ�ѹѹ�����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\CDFS.mat'); % ����CDFS(�����������ȼ�)�������ݡ���ԭʼ����

% ����ѹ�����ܵ����¡���ѹ
tube_TP = tube(H,Ma,r);    % function tube_TP=tube(H,Ma,r)
Tin_f = tube_TP(1,1); %������������
Pin_f = tube_TP(1,2); %����������ѹ
%% ���� ��Ҷ�Ƕ�һ��
alpha = get(handles.edit51,'string');      % ��Ҷ�Ƕ�
alpha=str2num(alpha);

zz = 0:0.01:1;       % ���Ⱥ�CDFS��ѹ�Ⱥ���ֵ��Ϊ0.5
nzz=size(zz);
nspeed =0:1.5/100:1.5;  % ���Ⱥ�CDFS������ת�ٶ�Ϊ0.95

for k=1:nzz(1,2)

    % �ڻ���ת��ncor�µ����Բ�ֵ ��ѹ�ȡ�Ч�ʡ���������
    ncor_data_f = linear_interp(Tind_f,Tin_f,nspeed(1,k),fan); % function ncor_data=linear_interp(Tind,Tin,n,data)
    % ������� ��ѹ�ȡ�Ч�ʡ���������
    com_ch_f = correct_com(ncor_data_f,alpha,0); % function com_ch=correct_com(data,alpha,flag)
    com_ch_f(1,:)=[]; % ��һ��Ϊ����ת��

    ncom=size(com_ch_f);
    prc=com_ch_f(:,1); % ��ѹ��
    nc=com_ch_f(:,2);  % Ч��
    Wc=com_ch_f(:,3);  % ����

    for i=1:nzz(1,2)
        pr(i,1)=(max(prc)-min(prc))*zz(1,i)+min(prc);
        [a,b]=min(abs(prc-pr(i,1))); % a ��Сֵ��b ��Сֵ����λ��
        WC(k,i)=Wc(b,1); % ncor��zz�µ�prc,nc,Wc
    end
    
end
[nsg,zzg]=meshgrid(nspeed,zz);
axes(handles.axes2);
surf(nsg,zzg,WC);
view([59.5 32]);
xlabel('����ת��');ylabel('ѹ�Ⱥ���ֵzz');zlabel('����');
grid on;title('��Ҷ�Ƕ�һ��������'); axis tight


function edit28_Callback(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit28 as text
%        str2double(get(hObject,'String')) returns contents of edit28 as a double


% --- Executes during object creation, after setting all properties.
function edit28_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global H Ma r Tind_f Tind_CDFS Tind_hcom Pind_f Pind_CDFS Pind_hcom Tin_f  Pin_f

load('D:\MATLAB Edit 2012B\ysw\20130920\data\fan.mat'); % ���ط����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\hcompressor.mat'); % ���ظ�ѹѹ�����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\CDFS.mat'); % ����CDFS(�����������ȼ�)�������ݡ���ԭʼ����

nspeed = get(handles.edit52,'string');  % ���Ⱥ�CDFS������ת�ٶ�Ϊ0.95
nspeed=str2num(nspeed);

alpha = -5:0.2:15;      % ��Ҷ�Ƕ�
zz = 0:0.01:1;       % ���Ⱥ�CDFS��ѹ�Ⱥ���ֵ��Ϊ0.5
nzz=size(zz);

for k=1:nzz(1,2)

    % �ڻ���ת��ncor�µ����Բ�ֵ ��ѹ�ȡ�Ч�ʡ���������
    ncor_data_f = linear_interp(Tind_f,Tin_f,nspeed,fan); % function ncor_data=linear_interp(Tind,Tin,n,data)
    % ������� ��ѹ�ȡ�Ч�ʡ���������
    com_ch_f = ncor_data_f; %correct_com(ncor_data_f,alpha(1,k),0); % function com_ch=correct_com(data,alpha,flag)
    com_ch_f(1,:)=[]; % ��һ��Ϊ����ת��

    ncom=size(com_ch_f);
    prc=com_ch_f(:,1); % ��ѹ��
    nc=com_ch_f(:,2);  % Ч��
    Wc=com_ch_f(:,3);  % ����

    for i=1:nzz(1,2)
        pr(i,1)=(max(prc)-min(prc))*zz(1,i)+min(prc);
        [a,b]=min(abs(prc-pr(i,1))); % a ��Сֵ��b ��Сֵ����λ��
        WC(k,i)=Wc(b,1); % ncor��zz�µ�prc,nc,Wc
    end
    
end
[alg,zzg]=meshgrid(alpha,zz);
axes(handles.axes1);
surf(alg,zzg,WC);
xlabel('��Ҷ�Ƕ�');ylabel('ѹ�Ⱥ���ֵzz');zlabel('����');
grid on;view([49.5 24]);
title('����ת��һ����δ����'); axis tight


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% ���� ����ת��һ��
global H Ma r Tind_f Tind_CDFS Tind_hcom Pind_f Pind_CDFS Pind_hcom Tin_f  Pin_f

load('D:\MATLAB Edit 2012B\ysw\20130920\data\fan.mat'); % ���ط����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\hcompressor.mat'); % ���ظ�ѹѹ�����������ݡ���ԭʼ����
load('D:\MATLAB Edit 2012B\ysw\20130920\data\CDFS.mat'); % ����CDFS(�����������ȼ�)�������ݡ���ԭʼ����

nspeed = get(handles.edit52,'string');  % ���Ⱥ�CDFS������ת�ٶ�Ϊ0.95
nspeed=str2num(nspeed);

alpha = -5:0.2:15;      % ��Ҷ�Ƕ�
zz = 0:0.01:1;       % ���Ⱥ�CDFS��ѹ�Ⱥ���ֵ��Ϊ0.5
nzz=size(zz);

for k=1:nzz(1,2)

    % �ڻ���ת��ncor�µ����Բ�ֵ ��ѹ�ȡ�Ч�ʡ���������
    ncor_data_f = linear_interp(Tind_f,Tin_f,nspeed,fan); % function ncor_data=linear_interp(Tind,Tin,n,data)
    % ������� ��ѹ�ȡ�Ч�ʡ���������
    com_ch_f = correct_com(ncor_data_f,alpha(1,k),0); % function com_ch=correct_com(data,alpha,flag)
    com_ch_f(1,:)=[]; % ��һ��Ϊ����ת��

    ncom=size(com_ch_f);
    prc=com_ch_f(:,1); % ��ѹ��
    nc=com_ch_f(:,2);  % Ч��
    Wc=com_ch_f(:,3);  % ����

    for i=1:nzz(1,2)
        pr(i,1)=(max(prc)-min(prc))*zz(1,i)+min(prc);
        [a,b]=min(abs(prc-pr(i,1))); % a ��Сֵ��b ��Сֵ����λ��
        WC(k,i)=Wc(b,1); % ncor��zz�µ�prc,nc,Wc
    end
    
end
[alg,zzg]=meshgrid(alpha,zz);
axes(handles.axes2);
surf(alg,zzg,WC);
xlabel('��Ҷ�Ƕ�');ylabel('ѹ�Ⱥ���ֵzz');zlabel('����');
grid on;view([49.5 24]);
title('����ת��һ��������'); axis tight

% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc,clear,close all

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')