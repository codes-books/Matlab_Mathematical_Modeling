%���ںϲ�
clc,clear;
load xsum.mat
load gw1.mat
load gw2.mat
load gw3.mat
load gw4.mat
load gw5.mat
load gw6.mat
load gw7.mat
n0=size(xsum);
n1=size(gw1);n2=size(gw2);n3=size(gw3);
n4=size(gw4);n5=size(gw5);n6=size(gw6);
n7=size(gw7);
renshu1=[0,0,0,0,0,0,0];keyan1=[0,0,0,0,0,0,0];zhongyw1=[0,0,0,0,0,0,0];
zhuanli1=[0,0,0,0,0,0,0];huoj1=[0,0,0,0,0,0,0];youxlw1=[0,0,0,0,0,0,0];
for i=1:n1(1,1)
    renshu1(1,1)=renshu1(1,1)+gw1(i,9);
    keyan1(1,1)=keyan1(1,1)+gw1(i,14);
    zhongyw1(1,1)=zhongyw1(1,1)+gw1(i,20)+gw1(i,29);
    zhuanli1(1,1)=zhuanli1(1,1)+gw1(i,35);
    huoj1(1,1)=huoj1(1,1)+gw1(i,41);
    youxlw1(1,1)=youxlw1(1,1)+gw1(i,42)+gw1(i,43);
end

for i=1:n2(1,1)
    renshu1(1,2)=renshu1(1,2)+gw2(i,9);
    keyan1(1,2)=keyan1(1,2)+gw2(i,14);
    zhongyw1(1,2)=zhongyw1(1,2)+gw2(i,20)+gw2(i,29);
    zhuanli1(1,2)=zhuanli1(1,2)+gw2(i,35);
    huoj1(1,2)=huoj1(1,2)+gw2(i,41);
    youxlw1(1,2)=youxlw1(1,2)+gw2(i,42)+gw2(i,43);
end

for i=1:n3(1,1)
    renshu1(1,3)=renshu1(1,3)+gw3(i,9);
    keyan1(1,3)=keyan1(1,3)+gw3(i,14);
    zhongyw1(1,3)=zhongyw1(1,3)+gw3(i,20)+gw3(i,29);
    zhuanli1(1,3)=zhuanli1(1,3)+gw3(i,35);
    huoj1(1,3)=huoj1(1,3)+gw3(i,41);
    youxlw1(1,3)=youxlw1(1,3)+gw3(i,42)+gw3(i,43);
end

for i=1:n4(1,1)
    renshu1(1,4)=renshu1(1,4)+gw4(i,9);
    keyan1(1,4)=keyan1(1,4)+gw4(i,14);
    zhongyw1(1,4)=zhongyw1(1,4)+gw4(i,20)+gw4(i,29);
    zhuanli1(1,4)=zhuanli1(1,4)+gw4(i,35);
    huoj1(1,4)=huoj1(1,4)+gw4(i,41);
    youxlw1(1,4)=youxlw1(1,4)+gw4(i,42)+gw4(i,43);
end

for i=1:n5(1,1)
    renshu1(1,5)=renshu1(1,5)+gw5(i,9);
    keyan1(1,5)=keyan1(1,5)+gw5(i,14);
    zhongyw1(1,5)=zhongyw1(1,5)+gw5(i,20)+gw5(i,29);
    zhuanli1(1,5)=zhuanli1(1,5)+gw5(i,35);
    huoj1(1,5)=huoj1(1,5)+gw5(i,41);
    youxlw1(1,5)=youxlw1(1,5)+gw5(i,42)+gw5(i,43);
end

for i=1:n6(1,1)
    renshu1(1,6)=renshu1(1,6)+gw6(i,9);
    keyan1(1,6)=keyan1(1,6)+gw6(i,14);
    zhongyw1(1,6)=zhongyw1(1,6)+gw6(i,20)+gw6(i,29);
    zhuanli1(1,6)=zhuanli1(1,6)+gw6(i,35);
    huoj1(1,6)=huoj1(1,6)+gw6(i,41);
    youxlw1(1,6)=youxlw1(1,6)+gw6(i,42)+gw6(i,43);
end

for i=1:n1(1,1)
    renshu1(1,7)=renshu1(1,7)+gw7(i,9);
    keyan1(1,7)=keyan1(1,7)+gw7(i,14);
    zhongyw1(1,7)=zhongyw1(1,7)+gw7(i,20)+gw7(i,29);
    zhuanli1(1,7)=zhuanli1(1,7)+gw7(i,35);
    huoj1(1,7)=huoj1(1,7)+gw7(i,41);
    youxlw1(1,7)=youxlw1(1,7)+gw7(i,42)+gw7(i,43);
end

subplot(2,3,1)
bar(1:7,renshu1)
gtext('����')
gtext('��������')
subplot(2,3,2)
bar(1:7,keyan1)
gtext('����')
gtext('���о���')
subplot(2,3,3)
bar(1:7,zhongyw1)
gtext('����')
gtext('��Ӣ��������')
subplot(2,3,4)
bar(1:7,zhuanli1)
gtext('����')
gtext('ר����')
subplot(2,3,5)
bar(1:7,huoj1)
gtext('����')
gtext('����')
subplot(2,3,6)
bar(1:7,youxlw1)
gtext('����')
gtext('����������')

%��ƽ��ֵ
    renshu1(1,1)=renshu1(1,1)/n1(1,1);
    keyan1(1,1)=keyan1(1,1)/n1(1,1);
    zhongyw1(1,1)=zhongyw1(1,1)/n1(1,1);
    zhuanli1(1,1)=zhuanli1(1,1)/n1(1,1);
    huoj1(1,1)=huoj1(1,1)/n1(1,1);
    youxlw1(1,1)=youxlw1(1,1)/n1(1,1);
%��ƽ��ֵ
    renshu1(1,2)=renshu1(1,2)/n2(1,1);
    keyan1(1,2)=keyan1(1,2)/n2(1,1);
    zhongyw1(1,2)=zhongyw1(1,2)/n2(1,1);
    zhuanli1(1,2)=zhuanli1(1,2)/n2(1,1);
    huoj1(1,2)=huoj1(1,2)/n2(1,1);
    youxlw1(1,2)=youxlw1(1,2)/n2(1,1);
%��ƽ��ֵ
    renshu1(1,3)=renshu1(1,3)/n3(1,1);
    keyan1(1,3)=keyan1(1,3)/n3(1,1);
    zhongyw1(1,3)=zhongyw1(1,3)/n3(1,1);
    zhuanli1(1,3)=zhuanli1(1,3)/n3(1,1);
    huoj1(1,3)=huoj1(1,3)/n3(1,1);
    youxlw1(1,3)=youxlw1(1,3)/n3(1,1);
%��ƽ��ֵ
    renshu1(1,4)=renshu1(1,4)/n4(1,1);
    keyan1(1,4)=keyan1(1,4)/n4(1,1);
    zhongyw1(1,4)=zhongyw1(1,4)/n4(1,1);
    zhuanli1(1,4)=zhuanli1(1,4)/n4(1,1);
    huoj1(1,4)=huoj1(1,4)/n4(1,1);
    youxlw1(1,4)=youxlw1(1,4)/n4(1,1);
%��ƽ��ֵ
    renshu1(1,5)=renshu1(1,5)/n5(1,1);
    keyan1(1,5)=keyan1(1,5)/n5(1,1);
    zhongyw1(1,5)=zhongyw1(1,5)/n5(1,1);
    zhuanli1(1,5)=zhuanli1(1,5)/n5(1,1);
    huoj1(1,5)=huoj1(1,5)/n5(1,1);
    youxlw1(1,5)=youxlw1(1,5)/n5(1,1);
%��ƽ��ֵ
    renshu1(1,6)=renshu1(1,6)/n6(1,1);
    keyan1(1,6)=keyan1(1,6)/n6(1,1);
    zhongyw1(1,6)=zhongyw1(1,6)/n6(1,1);
    zhuanli1(1,6)=zhuanli1(1,6)/n6(1,1);
    huoj1(1,6)=huoj1(1,6)/n6(1,1);
    youxlw1(1,6)=youxlw1(1,6)/n6(1,1);
%��ƽ��ֵ
    renshu1(1,7)=renshu1(1,7)/n7(1,1);
    keyan1(1,7)=keyan1(1,7)/n7(1,1);
    zhongyw1(1,7)=zhongyw1(1,7)/n7(1,1);
    zhuanli1(1,7)=zhuanli1(1,7)/n7(1,1);
    huoj1(1,7)=huoj1(1,7)/n7(1,1);
    youxlw1(1,7)=youxlw1(1,7)/n7(1,1);
figure(2),
subplot(2,3,1)
bar(1:7,renshu1)
gtext('����')
gtext('ƽ����������')
subplot(2,3,2)
bar(1:7,keyan1)
gtext('����')
gtext('ƽ�����о���')
subplot(2,3,3)
bar(1:7,zhongyw1)
gtext('����')
gtext('ƽ����Ӣ��������')
subplot(2,3,4)
bar(1:7,zhuanli1)
gtext('����')
gtext('ƽ��ר����')
subplot(2,3,5)
bar(1:7,huoj1)
gtext('����')
gtext('ƽ������')
subplot(2,3,6)
bar(1:7,youxlw1)
gtext('����')
gtext('ƽ������������')
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')