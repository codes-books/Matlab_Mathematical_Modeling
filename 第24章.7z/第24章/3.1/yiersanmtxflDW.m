%��һ������ҵú̿������DW����
clc,clear
load Bmtxfl.mat
n0=size(Bmtxfl);
for i=1:n0(1,1)
    msum(i,1)=-0.1008+0.5632*mtxfl(i,2)-0.293*mtxfl(i,3)-0.0248*mtxfl(i,4);
end
for i=1:n0(1,1)
    error(i,1)=mtxfl(i,5)-msum(i,1);
end
e1=error(1:n0(1,1)-1,:);
e2=error(2:n0(1,1),:);
delta=0;
E2=0;
for i=1:n0(1,1)-1
    delta=delta+(e2(i,1)-e1(i,1))*(e2(i,1)-e1(i,1));
    E2=E2+e2(i,1)*e2(i,1);
end
DW=delta/E2;

plot(e1,e2,'+')
xlabel('e1')
ylabel('e2')
title('ģ��DW����')

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')