clc,clear
load biao3.mat
%ȫ��һ�в�������
n0=size(biao3);
k=1;m=1;
for i=1:(n0(1,1)-1)
    yh(i,m)=biao3(i,3);
    hangh(i,k)=i;
    for j=(i+1):n0(1,1)
        if abs(biao3(j,3)-biao3(i,3))/biao3(j,3)<=0.1||abs(biao3(j,3)-biao3(i,3))/biao3(i,3)<=0.1
            k=k+1;
            m=m+1;
            yh(i,m)=biao3(j,3);
            hangh(i,k)=j;
        end
    end
    m=m+1;
end
n1=size(hangh);
k=1;l=1;
for i=1:n1(1,1)
    for j=1:n1(1,2)
        if hangh(i,j)~=0
            jianhhangh(i,l)=hangh(i,j);
            l=l+1;
        end
    end
end


        
        
        
        
        
        
        
        
        
        
        
        
        
        
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')