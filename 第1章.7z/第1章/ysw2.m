%% matrix
clc,clear,close all
zeros(3)
eye(3)
%% ����
clc,clear,close all
A = rand(3)
A^3
A.^3
A^3/A.^3
A^3-A.^3
A^3+A.^3
%% hankel����
clc,clear,close all
c=[1:5],
r=[3:9],
H=hankel(c,r)

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')