%���ںϲ�
clc,clear;
load xsum.mat
load xuekepj.mat
n0=size(xsum);
j=1;
for i=1:n0(1,1)
    if xsum(i,3)~=0
        zq(j,:)=xsum(i,:);
        j=j+1;
    end
end
n1=size(zq);
%11��������
for i=1:n1(1,1)
    fpfa12(i,1)=zq(i,3);
    fpfa12(i,2)=zq(i,19);
    fpfa12(i,3)=zq(i,28);
    fpfa12(i,4)=zq(i,34);
    fpfa12(i,5)=zq(i,40);
    fpfa12(i,6)=xuekepj(i,1);
end
for i=1:n1(1,1)
    if fpfa12(i,1)==1
        fpfa12(i,1)=7;
    end
    if fpfa12(i,1)==2
        fpfa12(i,1)=6;
    end
    if fpfa12(i,1)==3
        fpfa12(i,1)=5; 
    end
    if fpfa12(i,1)==4
        fpfa12(i,1)=4;
    end
    if fpfa12(i,1)==5
        fpfa12(i,1)=3; 
    end
    if fpfa12(i,1)==6
        fpfa12(i,1)=2;
    end
    if fpfa12(i,1)==7
        fpfa12(i,1)=1; 
    end
end
fpfa12=zscore(fpfa12);%��׼������
n2=size(fpfa12);
for i=1:n2(1,1)
    Byucers(i,1)=-0.3333+0.36095*fpfa12(i,1)+0.0364*fpfa12(i,2)+0.05495*fpfa12(i,3)+0.018*fpfa12(i,4)+0.0107*fpfa12(i,5)+0.0022*fpfa12(i,6);
end
std11=1.8724;std10=1.8724;std09=1.6382;std08=1.7656;
mean11=1.7384;mean10=1.7384;mean09=1.3169;mean08=1.1395;
std=(std11+std10+std09+std08)/4;
mean=(mean11+mean10+mean09+mean08)/4;

for i=1:n2(1,1)
    yucers(i,1)=Byucers(i,1)*std+mean11;
    yucers(i,2)=floor(yucers(i,1))+1;
end



 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')