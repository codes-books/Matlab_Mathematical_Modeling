%���ںϲ�
clc,clear;
load xsum.mat
n0=size(xsum);
j=1;
for i=1:n0(1,1)
    if xsum(i,3)~=0
        zq(j,:)=xsum(i,:);
        j=j+1;
    end
end
n1=size(zq);
%08��������
for i=1:n1(1,1)
    fpfa11(i,1)=zq(i,3);
    fpfa11(i,2)=zq(i,18);
    fpfa11(i,3)=zq(i,27);
    fpfa11(i,4)=zq(i,33);
    fpfa11(i,5)=zq(i,39);
    fpfa11(i,6)=zq(i,7);
end
for i=1:n1(1,1)
    if fpfa11(i,1)==1
        fpfa11(i,1)=7;
    end
    if fpfa11(i,1)==2
        fpfa11(i,1)=6;
    end
    if fpfa11(i,1)==3
        fpfa11(i,1)=5; 
    end
    if fpfa11(i,1)==4
        fpfa11(i,1)=4;
    end
    if fpfa11(i,1)==5
        fpfa11(i,1)=3; 
    end
    if fpfa11(i,1)==6
        fpfa11(i,1)=2;
    end
    if fpfa11(i,1)==7
        fpfa11(i,1)=1; 
    end
end
n2=size(fpfa11);
% Bfpfa08=zscore(fpfa08(:,1:n2(1,2)-1));  % ��׼�����ݾ���
% Bfpfa08(:,n2(1,2))=fpfa08(:,n2(1,2)); 

% figure(1),
% subplot(2,3,1)
% plot(fpfa08(:,1),fpfa08(:,6));%����
% subplot(2,3,2)
% plot(fpfa08(:,2),fpfa08(:,6));%Ӣ������
% subplot(2,3,3)
% plot(fpfa08(:,2),fpfa08(:,6));%��������
% subplot(2,2,3)
% plot(fpfa08(:,4),fpfa08(:,6));%ר����
% subplot(2,2,4)
% plot(fpfa08(:,5),fpfa08(:,6));%�񽱸���

figure(1),
X=fpfa11(:,1:5);
X=[ones(n2(1,1),1),X];
Y=fpfa11(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n1(1,1)
    if i~=33&&i~=41&&i~=91&&i~=113&&i~=131&&i~=132&&i~=143&&i~=167&&i~=213&&i~=215&&i~=220&&i~=224&&i~=255&&i~=257&&i~=261&&i~=266&&i~=251&&i~=252&&i~=264&&i~=269
        Cfpfa11(j,:)=fpfa11(i,:);
        j=j+1;
    end
end
figure(2),
n3=size(Cfpfa11);
X=Cfpfa11(:,1:5);
X=[ones(n3(1,1),1),X];
Y=Cfpfa11(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n3(1,1)
    if i~=5&&i~=76&&i~=96&&i~=130&&i~=111&&i~=151&&i~=136&&i~=166&&i~=190&&i~=197&&i~=205&&i~=209&&i~=230&&i~=233&&i~=217&&i~=238&&i~=262&&i~=279&&i~=158&&i~=156
        CCfpfa11(j,:)=Cfpfa11(i,:);
        j=j+1;
    end
end
figure(3),
n3=size(CCfpfa11);
X=CCfpfa11(:,1:5);
X=[ones(n3(1,1),1),X];
Y=CCfpfa11(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n3(1,1)
    if i~=2&&i~=27&&i~=148&&i~=156&&i~=184&&i~=215&&i~=226&&i~=254&&i~=283&&i~=293
        CCCfpfa11(j,:)=CCfpfa11(i,:);
        j=j+1;
    end
end
figure(4),
n3=size(CCCfpfa11);
X=CCCfpfa11(:,1:5);
X=[ones(n3(1,1),1),X];
Y=CCCfpfa11(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n3(1,1)
    if i~=82&&i~=86&&i~=190&&i~=200&&i~=203&&i~=241
        CCCCfpfa11(j,:)=CCCfpfa11(i,:);
        j=j+1;
    end
end
figure(5),
n3=size(CCCCfpfa11);
X=CCCCfpfa11(:,1:5);
X=[ones(n3(1,1),1),X];
Y=CCCCfpfa11(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n3(1,1)
    if i~=144&&i~=147&&i~=122
        CCCCCfpfa11(j,:)=CCCCfpfa11(i,:);
        j=j+1;
    end
end
figure(6),
n3=size(CCCCCfpfa11);
X=CCCCCfpfa11(:,1:5);
X=[ones(n3(1,1),1),X];
Y=CCCCCfpfa11(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)
% 
% %ɾ��һЩ��
% j=1;
% for i=1:n3(1,1)
%     if i~=31&&i~=99&&i~=100&&i~=118&&i~=146&&i~=136&&i~=141&&i~=183&&i~=169&&i~=179&&i~=248&&i~=249&&i~=254&&i~=255&&i~=252&&i~=164&&i~=153&&i~=167&&i~=178
%         CCCCCCfpfa08(j,:)=CCCCCfpfa08(i,:);
%         j=j+1;
%     end
% end
% figure(7),
% n3=size(CCCCCCfpfa08);
% X=CCCCCCfpfa08(:,1:5);
% X=[ones(n3(1,1),1),X];
% Y=CCCCCCfpfa08(:,n2(1,2)); 
% [b,bint,r,rint,s]=regress(Y,X);
% rcoplot(r,rint)
% 
% 
% %ɾ��һЩ��
% j=1;
% for i=1:n3(1,1)
%     if i~=52&&i~=17&&i~=83&&i~=121&&i~=245&&i~=232&&i~=174&&i~=148&&i~=129&&i~=115&&i~=109&&i~=100&&i~=97
%         CCCCCCCfpfa08(j,:)=CCCCCCfpfa08(i,:);
%         j=j+1;
%     end
% end
% figure(8),
% n3=size(CCCCCCCfpfa08);
% X=CCCCCCCfpfa08(:,1:5);
% X=[ones(n3(1,1),1),X];
% Y=CCCCCCCfpfa08(:,n2(1,2)); 
% [b,bint,r,rint,s]=regress(Y,X);
% rcoplot(r,rint)
% 
% %ɾ��һЩ��
% j=1;
% for i=1:n3(1,1)
%     if i~=3&&i~=5&&i~=12&&i~=14&&i~=40&&i~=46&&i~=53&&i~=66&&i~=73&&i~=75&&i~=139&&i~=151&&i~=154&&i~=156&&i~=159&&i~=214&&i~=220&&i~=222&&i~=224&&i~=206&&i~=202&&i~=165&&i~=115
%         CCCCCCCCfpfa08(j,:)=CCCCCCCfpfa08(i,:);
%         j=j+1;
%     end
% end
% figure(9),
% n3=size(CCCCCCCCfpfa08);
% X=CCCCCCCCfpfa08(:,1:5);
% X=[ones(n3(1,1),1),X];
% Y=CCCCCCCCfpfa08(:,n2(1,2)); 
% [b,bint,r,rint,s]=regress(Y,X);
% rcoplot(r,rint)
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')