clc,clear,close all
ysw18_7;
load('matlab.mat')
a2=max(x7);
a2=max(a2');
b2=min(x7);
b2=min(b2');
for i=1:52
    for j=1:52
        x7(i,j)=(a2-x7(i,j))/(a2-b2);
    end
end
x8(1,1)=x7(1,1)*freqd(1,1)+x7(1,28)*freqd(1,28)+x7(1,29)*freqd(1,29)+x7(1,30)*freqd(1,30)+x7(1,31)*freqd(1,31)+x7(1,51)*freqd(1,51)+x7(1,52)*freqd(1,52);
x8(2,1)=x7(2,2)*freqd(1,2)+x7(2,32)*freqd(1,32)+x7(2,33)*freqd(1,34)+x7(2,34)*freqd(1,34)+x7(2,35)*freqd(1,35)+x7(2,36)*freqd(1,36)+x7(2,37)*freqd(1,37)+x7(2,38)*freqd(1,38)+x7(2,39)*freqd(1,39)+x7(2,40)*freqd(1,40)+x7(2,41)*freqd(1,41)+x7(2,49)*freqd(1,49)+x7(2,50)*freqd(1,50);
x8(3,1)=x7(3,3)*freqd(1,3)+x7(3,48)*freqd(1,48);
x8(4,1)=x7(4,4)*freqd(1,4)+x7(4,25)*freqd(1,25)+x7(4,26)*freqd(1,26)+x7(4,42)*freqd(1,42)+x7(4,43)*freqd(1,43);
x8(5,1)=x7(5,5)*freqd(1,5)+x7(5,44)*freqd(1,44)+x7(5,45)*freqd(1,45)+x7(5,46)*freqd(1,46)+x7(5,47)*freqd(1,47);
x8(6,1)=x7(6,6)*freqd(1,6);
x8(7,1)=x7(7,7)*freqd(1,7)+x7(7,24)*freqd(1,24)+x7(7,27)*freqd(1,27);
x8(8,1)=x7(8,8)*freqd(1,8)+x7(8,18)*freqd(1,18)+x7(8,19)*freqd(1,19)+x7(8,21)*freqd(1,21)+x7(8,22)*freqd(1,22)+x7(8,23)*freqd(1,23);
x8(9,1)=x7(9,9)*freqd(1,9)+x7(9,10)*freqd(1,10)+x7(9,11)*freqd(1,11)+x7(9,12)*freqd(1,12)+x7(9,13)*freqd(1,13)+x7(9,14)*freqd(1,14)+x7(9,15)*freqd(1,15)+x7(9,16)*freqd(1,16)+x7(9,17)*freqd(1,17)+x7(9,20)*freqd(1,20);
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')