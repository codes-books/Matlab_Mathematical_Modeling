clc,clear,close all
p=1.5:0.001:1.70;
Q=-50000*p.^2+155000*p-120000;
max(Q)
plot(p,Q)
hold on
Q=0;
plot(p,Q)
xlabel('p')
ylabel('Q')


 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')