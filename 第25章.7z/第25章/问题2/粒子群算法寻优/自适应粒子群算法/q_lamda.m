function y=q_lamda(lamda,r)
% q(��)
y= ((r+1)/2).^(1/(r-1))*lamda*(1-(r-1)/(r+1)*lamda^2)^(1/(r-1));
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')