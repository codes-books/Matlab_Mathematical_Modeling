%���ںϲ�
clc,clear;
load jlEO.mat
n0=size(OED);
jlEzxjl(1,1)=min(OED(n0(1,1),1:n0(1,2)-1));
for i=1:n0(1,2)-1
    if jlEzxjl(1,1)==OED(n0(1,1),i);
       jlEzxjl(1,2)=i;
    end
end



 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')