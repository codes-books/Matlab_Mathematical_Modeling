clc,clear
load pusheshuju.mat
n=size(youhuaiqujie);
a=youhuaiqujie;
for i=1:n(1,1)
    ns(i,1)=(a(i,2)+a(i,3))/(a(i,1)*0.5);
end
fast=min(ns);
k=1;
for i=1:n(1,1)
    if ns(i,1)==fast;
        b(k,1)=i;
        k=k+1;
    end
end

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')