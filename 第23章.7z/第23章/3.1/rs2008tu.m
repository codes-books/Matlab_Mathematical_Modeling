%���ںϲ�
clc,clear;
load xsum.mat
n0=size(xsum);
j=1;
for i=1:n0(1,1)
    if xsum(i,3)~=0
        zq(j,:)=xsum(i,:);
        j=j+1;
    end
end
n1=size(zq);
%08��������
for i=1:n1(1,1)
    fpfa08(i,1)=zq(i,3);
    fpfa08(i,2)=zq(i,15);
    fpfa08(i,3)=zq(i,24);
    fpfa08(i,4)=zq(i,30);
    fpfa08(i,5)=zq(i,36);
    fpfa08(i,6)=zq(i,5);
end
for i=1:n1(1,1)
    if fpfa08(i,1)==1
        fpfa08(i,1)=7;
    end
    if fpfa08(i,1)==2
        fpfa08(i,1)=6;
    end
    if fpfa08(i,1)==3
        fpfa08(i,1)=5; 
    end
    if fpfa08(i,1)==4
        fpfa08(i,1)=4;
    end
    if fpfa08(i,1)==5
        fpfa08(i,1)=3; 
    end
    if fpfa08(i,1)==6
        fpfa08(i,1)=2;
    end
    if fpfa08(i,1)==7
        fpfa08(i,1)=1; 
    end
end
n2=size(fpfa08);
for i=1:n2(1,1)
    yucers(i,1)=-0.1884+0.3112*fpfa08(i,1)-0.43*fpfa08(i,2)+0.0049*fpfa08(i,3)-0.0336*fpfa08(i,4)+2.9437*fpfa08(i,5);
    yucers(i,1)=floor(yucers(i,1))+1;
    yucers(i,2)=fpfa08(i,6);
end
plot(1:n2(1,1),yucers(:,1))
hold on
plot(1:n2(1,1),yucers(:,2))  
    
    
    
    
    
    
    
    
    
    
    
    

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')