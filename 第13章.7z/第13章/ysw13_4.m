clc,clear,close all
load('data1.mat')
x1 = [data1(2,1:end-1),data1(8,1:4)];
y1 = [data1(3,1:end-1),data1(9,1:4)];
x2 = [data1(8,5:end-1),data1(14,1:end)];
y2 = [data1(9,5:end-1),data1(15,1:end)];
plot([y1,y2],[x1,x2],'b.')
a = polyfit([y1,y2],[x1,x2],2);
y = min([y1,y2])-10:max([y1,y2])+10;
x = a(1)*y.^2+a(2)*y+a(3);
hold on
plot(y,x,'r.--','linewidth',2)

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')