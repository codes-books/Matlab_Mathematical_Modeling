%���ںϲ�
clc,clear;
load xsum.mat
load xuekepj.mat
n0=size(xsum);
j=1;
for i=1:n0(1,1)
    if xsum(i,3)~=0
        zq(j,:)=xsum(i,:);
        j=j+1;
    end
end
n1=size(zq);
%08��������
for i=1:n1(1,1)
    fpfa09(i,1)=zq(i,3);
    fpfa09(i,2)=zq(i,16);
    fpfa09(i,3)=zq(i,25);
    fpfa09(i,4)=zq(i,31);
    fpfa09(i,5)=zq(i,37);
    fpfa09(i,6)=xuekepj(i,1);
    fpfa09(i,7)=zq(i,6);
end
for i=1:n1(1,1)
    if fpfa09(i,1)==1
        fpfa09(i,1)=7;
    end
    if fpfa09(i,1)==2
        fpfa09(i,1)=6;
    end
    if fpfa09(i,1)==3
        fpfa09(i,1)=5; 
    end
    if fpfa09(i,1)==4
        fpfa09(i,1)=4;
    end
    if fpfa09(i,1)==5
        fpfa09(i,1)=3; 
    end
    if fpfa09(i,1)==6
        fpfa09(i,1)=2;
    end
    if fpfa09(i,1)==7
        fpfa09(i,1)=1; 
    end
end

a=mean(fpfa09);
% %a=mean(a');
a1=std(fpfa09);

fpfa09=zscore(fpfa09);%��׼������
n2=size(fpfa09);
% Bfpfa08=zscore(fpfa08(:,1:n2(1,2)-1));  % ��׼�����ݾ���
% Bfpfa08(:,n2(1,2))=fpfa08(:,n2(1,2)); 

% figure(1),
% subplot(2,3,1)
% plot(fpfa08(:,1),fpfa08(:,6));%����
% subplot(2,3,2)
% plot(fpfa08(:,2),fpfa08(:,6));%Ӣ������
% subplot(2,3,3)
% plot(fpfa08(:,2),fpfa08(:,6));%��������
% subplot(2,2,3)
% plot(fpfa08(:,4),fpfa08(:,6));%ר����
% subplot(2,2,4)
% plot(fpfa08(:,5),fpfa08(:,6));%�񽱸���

figure(1),
X=fpfa09(:,1:6);
X=[ones(n2(1,1),1),X];
Y=fpfa09(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n1(1,1)
    if i~=1&&i~=41&&i~=91&&i~=99&&i~=105&&i~=113&&i~=143&&i~=131&&i~=167&&i~=174&&i~=205&&i~=214&&i~=252&&i~=264&&i~=255&&i~=257&&i~=261&&i~=266
        Cfpfa09(j,:)=fpfa09(i,:);
        j=j+1;
    end
end
figure(2),
n3=size(Cfpfa09);
X=Cfpfa09(:,1:6);
X=[ones(n3(1,1),1),X];
Y=Cfpfa09(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n3(1,1)
    if i~=6&&i~=32&&i~=55&&i~=76&&i~=81&&i~=90&&i~=109&&i~=127&&i~=133&&i~=134&&i~=144&&i~=125&&i~=150&&i~=154&&i~=208&&i~=219&&i~=224&&i~=233&&i~=246&&i~=251&&i~=297&&i~=312
        CCfpfa09(j,:)=Cfpfa09(i,:);
        j=j+1;
    end
end
figure(3),
n3=size(CCfpfa09);
X=CCfpfa09(:,1:6);
X=[ones(n3(1,1),1),X];
Y=CCfpfa09(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n3(1,1)
    if i~=1&&i~=33&&i~=35&&i~=42&&i~=60&&i~=107&&i~=150&&i~=294&&i~=201&&i~=209&&i~=214&&i~=213&&i~=223&&i~=235&&i~=250&&i~=270&&i~=300&&i~=296
        CCCfpfa09(j,:)=CCfpfa09(i,:);
        j=j+1;
    end
end
figure(4),
n3=size(CCCfpfa09);
X=CCCfpfa09(:,1:6);
X=[ones(n3(1,1),1),X];
Y=CCCfpfa09(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n3(1,1)
    if i~=60&&i~=64&&i~=75&&i~=76&&i~=88&&i~=97&&i~=109&&i~=112&&i~=140&&i~=198&&i~=199&&i~=206&&i~=224&&i~=281
        CCCCfpfa09(j,:)=CCCfpfa09(i,:);
        j=j+1;
    end
end
figure(5),
n3=size(CCCCfpfa09);
X=CCCCfpfa09(:,1:6);
X=[ones(n3(1,1),1),X];
Y=CCCCfpfa09(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

% %ɾ��һЩ��
% j=1;
% for i=1:n3(1,1)
%     if i~=13&&i~=30&&i~=57&&i~=68&&i~=82&&i~=85&&i~=92&&i~=106&&i~=193&&i~=263
%         CCCCCfpfa08(j,:)=CCCCfpfa08(i,:);
%         j=j+1;
%     end
% end
% figure(6),
% n3=size(CCCCCfpfa08);
% X=CCCCCfpfa08(:,1:5);
% X=[ones(n3(1,1),1),X];
% Y=CCCCCfpfa08(:,n2(1,2)); 
% [b,bint,r,rint,s]=regress(Y,X);
% rcoplot(r,rint)
% 
% %ɾ��һЩ��
% j=1;
% for i=1:n3(1,1)
%     if i~=31&&i~=99&&i~=100&&i~=118&&i~=146&&i~=136&&i~=141&&i~=183&&i~=169&&i~=179&&i~=248&&i~=249&&i~=254&&i~=255&&i~=252&&i~=164&&i~=153&&i~=167&&i~=178
%         CCCCCCfpfa08(j,:)=CCCCCfpfa08(i,:);
%         j=j+1;
%     end
% end
% figure(7),
% n3=size(CCCCCCfpfa08);
% X=CCCCCCfpfa08(:,1:5);
% X=[ones(n3(1,1),1),X];
% Y=CCCCCCfpfa08(:,n2(1,2)); 
% [b,bint,r,rint,s]=regress(Y,X);
% rcoplot(r,rint)
% 
% 
% %ɾ��һЩ��
% j=1;
% for i=1:n3(1,1)
%     if i~=52&&i~=17&&i~=83&&i~=121&&i~=245&&i~=232&&i~=174&&i~=148&&i~=129&&i~=115&&i~=109&&i~=100&&i~=97
%         CCCCCCCfpfa08(j,:)=CCCCCCfpfa08(i,:);
%         j=j+1;
%     end
% end
% figure(8),
% n3=size(CCCCCCCfpfa08);
% X=CCCCCCCfpfa08(:,1:5);
% X=[ones(n3(1,1),1),X];
% Y=CCCCCCCfpfa08(:,n2(1,2)); 
% [b,bint,r,rint,s]=regress(Y,X);
% rcoplot(r,rint)
% 
% %ɾ��һЩ��
% j=1;
% for i=1:n3(1,1)
%     if i~=3&&i~=5&&i~=12&&i~=14&&i~=40&&i~=46&&i~=53&&i~=66&&i~=73&&i~=75&&i~=139&&i~=151&&i~=154&&i~=156&&i~=159&&i~=214&&i~=220&&i~=222&&i~=224&&i~=206&&i~=202&&i~=165&&i~=115
%         CCCCCCCCfpfa08(j,:)=CCCCCCCfpfa08(i,:);
%         j=j+1;
%     end
% end
% figure(9),
% n3=size(CCCCCCCCfpfa08);
% X=CCCCCCCCfpfa08(:,1:5);
% X=[ones(n3(1,1),1),X];
% Y=CCCCCCCCfpfa08(:,n2(1,2)); 
% [b,bint,r,rint,s]=regress(Y,X);
% rcoplot(r,rint)
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')