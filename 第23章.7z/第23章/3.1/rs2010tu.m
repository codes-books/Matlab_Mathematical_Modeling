%���ںϲ�
clc,clear;
load xsum.mat
n0=size(xsum);
j=1;
for i=1:n0(1,1)
    if xsum(i,3)~=0
        zq(j,:)=xsum(i,:);
        j=j+1;
    end
end
n1=size(zq);
%08��������
for i=1:n1(1,1)
    fpfa10(i,1)=zq(i,3);
    fpfa10(i,2)=zq(i,17);
    fpfa10(i,3)=zq(i,26);
    fpfa10(i,4)=zq(i,32);
    fpfa10(i,5)=zq(i,38);
    fpfa10(i,6)=zq(i,7);
end
for i=1:n1(1,1)
    if fpfa10(i,1)==1
        fpfa10(i,1)=7;
    end
    if fpfa10(i,1)==2
        fpfa10(i,1)=6;
    end
    if fpfa10(i,1)==3
        fpfa10(i,1)=5; 
    end
    if fpfa10(i,1)==4
        fpfa10(i,1)=4;
    end
    if fpfa10(i,1)==5
        fpfa10(i,1)=3; 
    end
    if fpfa10(i,1)==6
        fpfa10(i,1)=2;
    end
    if fpfa10(i,1)==7
        fpfa10(i,1)=1; 
    end
end
n2=size(fpfa10);
for i=1:n2(1,1)
    yucers(i,1)=0.0344+0.5442*fpfa10(i,1)+0.2518*fpfa10(i,2)+0.1768*fpfa10(i,3)+0.0417*fpfa10(i,4)+0.3944*fpfa10(i,5);
    yucers(i,1)=floor(yucers(i,1))+1;
    yucers(i,2)=fpfa10(i,6);
end
plot(1:n2(1,1),yucers(:,1))
hold on
plot(1:n2(1,1),yucers(:,2))  










 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')