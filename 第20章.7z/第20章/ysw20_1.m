%1.1����н��ֱ�����
t=[1,2,3,4,5,6,7,8,9];
x1=[839	935	1050	1188	1336	1443	1380	1546	1662];
x2=[1035	1170	1335	1530	1738	1825	1761	2033	2331];
x3=[1391	1609	1988	2393	2716	3200	2725	3192	3590];
subplot(1,3,1)
plot(t,x1,'+')
hold on
x=polyfit(t,x1,1);
t1=0:0.01:10;
y=x(1,1)*t1+x(1,2);
plot(t1,y,'r');
title('ר����нԤ��ͼ')
subplot(1,3,2)
plot(t,x2,'+')
hold on
x=polyfit(t,x2,1);
t1=0:0.01:10;
y=x(1,1)*t1+x(1,2);
plot(t1,y,'r');
title('������нԤ��ͼ')
subplot(1,3,3)
plot(t,x3,'+')
hold on
x=polyfit(t,x3,1);
t1=0:0.01:10;
y=x(1,1)*t1+x(1,2);
plot(t1,y,'r');
title('˶ʿ��нԤ��ͼ')



 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')