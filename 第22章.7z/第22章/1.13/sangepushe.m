clc,clear
load biao3.mat
load diyiz.mat
load nibian.mat
n0=size(diyiz);
n1=size(nibian);
k=1;
i=2;
m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+2),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+2),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+2),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+3),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+3),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+3),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+4),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+4),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+4),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+5),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+5),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+5),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+5),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%134
m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+2),5)+biao3(diyiz(i,j+3),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+2),6)+biao3(diyiz(i,j+3),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+2),2)+biao3(diyiz(i,j+3),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+2),5)+biao3(diyiz(i,j+4),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+2),6)+biao3(diyiz(i,j+4),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+2),2)+biao3(diyiz(i,j+4),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))+(biao3(diyiz(i,j+5),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+2),5)+biao3(diyiz(i,j+5),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+2),6)+biao3(diyiz(i,j+5),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+2),2)+biao3(diyiz(i,j+5),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%145
m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+3),5)+biao3(diyiz(i,j+4),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+3),6)+biao3(diyiz(i,j+4),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+3),2)+biao3(diyiz(i,j+4),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))+(biao3(diyiz(i,j+5),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+3),5)+biao3(diyiz(i,j+5),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+3),6)+biao3(diyiz(i,j+5),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+3),2)+biao3(diyiz(i,j+5),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%156
m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))+(biao3(diyiz(i,j+5),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+4),5)+biao3(diyiz(i,j+5),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+4),6)+biao3(diyiz(i,j+5),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+4),2)+biao3(diyiz(i,j+5),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%234
m=1;p=1;p1=1;p2=1;
nn=1;j=2;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+2),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+2),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+2),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=2;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+3),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+3),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+3),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=2;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+4),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+4),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+4),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%245
m=1;p=1;p1=1;p2=1;
nn=1;j=2;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+2),5)+biao3(diyiz(i,j+3),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+2),6)+biao3(diyiz(i,j+3),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+2),2)+biao3(diyiz(i,j+3),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=2;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+2),5)+biao3(diyiz(i,j+4),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+2),6)+biao3(diyiz(i,j+4),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+2),2)+biao3(diyiz(i,j+4),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=2;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+3),5)+biao3(diyiz(i,j+4),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+3),6)+biao3(diyiz(i,j+4),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+3),2)+biao3(diyiz(i,j+4),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%345
m=1;p=1;p1=1;p2=1;
nn=1;j=3;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+2),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+2),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+2),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%346
m=1;p=1;p1=1;p2=1;
nn=1;j=3;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+3),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+3),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+3),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%356
m=1;p=1;p1=1;p2=1;
nn=1;j=3;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+2),5)+biao3(diyiz(i,j+3),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+2),6)+biao3(diyiz(i,j+3),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+2),2)+biao3(diyiz(i,j+3),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%456
m=1;p=1;p1=1;p2=1;
nn=1;j=4;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+2),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+2),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+2),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;
i=3;
m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+2),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+2),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+2),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+3),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+3),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+3),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+4),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+4),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+4),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+5),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+5),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+5),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+5),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%134
m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+2),5)+biao3(diyiz(i,j+3),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+2),6)+biao3(diyiz(i,j+3),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+2),2)+biao3(diyiz(i,j+3),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+2),5)+biao3(diyiz(i,j+4),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+2),6)+biao3(diyiz(i,j+4),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+2),2)+biao3(diyiz(i,j+4),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))+(biao3(diyiz(i,j+5),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+2),5)+biao3(diyiz(i,j+5),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+2),6)+biao3(diyiz(i,j+5),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+2),2)+biao3(diyiz(i,j+5),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%145
m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+3),5)+biao3(diyiz(i,j+4),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+3),6)+biao3(diyiz(i,j+4),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+3),2)+biao3(diyiz(i,j+4),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))+(biao3(diyiz(i,j+5),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+3),5)+biao3(diyiz(i,j+5),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+3),6)+biao3(diyiz(i,j+5),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+3),2)+biao3(diyiz(i,j+5),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%156
m=1;p=1;p1=1;p2=1;
nn=1;j=1;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))+(biao3(diyiz(i,j+5),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+4),5)+biao3(diyiz(i,j+5),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+4),6)+biao3(diyiz(i,j+5),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+4),2)+biao3(diyiz(i,j+5),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%234
m=1;p=1;p1=1;p2=1;
nn=1;j=2;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+2),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+2),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+2),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=2;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+3),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+3),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+3),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=2;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+4),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+4),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+4),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%245
m=1;p=1;p1=1;p2=1;
nn=1;j=2;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+2),5)+biao3(diyiz(i,j+3),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+2),6)+biao3(diyiz(i,j+3),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+2),2)+biao3(diyiz(i,j+3),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=2;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+2),5)+biao3(diyiz(i,j+4),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+2),6)+biao3(diyiz(i,j+4),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+2),2)+biao3(diyiz(i,j+4),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

m=1;p=1;p1=1;p2=1;
nn=1;j=2;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))+(biao3(diyiz(i,j+4),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+3),5)+biao3(diyiz(i,j+4),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+3),6)+biao3(diyiz(i,j+4),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+3),2)+biao3(diyiz(i,j+4),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%345
m=1;p=1;p1=1;p2=1;
nn=1;j=3;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+2),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+2),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+2),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%346
m=1;p=1;p1=1;p2=1;
nn=1;j=3;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+3),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+3),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+3),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%356
m=1;p=1;p1=1;p2=1;
nn=1;j=3;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))+(biao3(diyiz(i,j+3),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+2),5)+biao3(diyiz(i,j+3),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+2),6)+biao3(diyiz(i,j+3),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+2),2)+biao3(diyiz(i,j+3),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;

%456
m=1;p=1;p1=1;p2=1;
nn=1;j=4;
n2=floor(3.2/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))));
fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+2),5))*n2;%������
fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+2),6))*n2;%��������
for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+2),2))*n2) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
end
fadian(k,m+2)=min(a1);%���������
k=k+1;



 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')