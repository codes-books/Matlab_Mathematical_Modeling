%���ںϲ�
clc,clear;
load jlCO.mat
n0=size(OCD);
jlCzxjl(1,1)=min(OCD(n0(1,1)-1,1:n0(1,2)-2));
for i=1:n0(1,2)-2
    if jlCzxjl(1,1)==OCD(n0(1,1)-1,i);
       jlCzxjl(1,2)=i;
    end
end
jlCzxjl(2,1)=min(OCD(n0(1,1),1:n0(1,2)-2));
for i=1:n0(1,2)-2
    if jlCzxjl(2,1)==OCD(n0(1,1),i);
       jlCzxjl(2,2)=i;
    end
end



 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')