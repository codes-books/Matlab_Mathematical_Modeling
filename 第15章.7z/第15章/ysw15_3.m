clc,clear,close all
Y=0:12;
GDP=[3540 3783 3916 4239 4922 5560 6399 7842 9116 10879 13475 16737 18745];
P=[767 895 995 1117 1261 1437 1640 1957 2244 2489 2801 3096 3500];
subplot(121),plot(Y,GDP,'bo')
xlabel('ʱ��')
ylabel('GDP')
title('GDP��ʱ�䣨�꣩��ɢ��ͼ')
subplot(122),plot(P,GDP,'bo')
xlabel('���ۣ�Ԫ��')
ylabel('GDP')
title('GDP�Է��ۣ�Ԫ����ɢ��ͼ')
%%
clc,clear,close all
Y=0:12;
GDP=[3540 3783 3916 4239 4922 5560 6399 7842 9116 10879 13475 16737 18745];
P=[767 895 995 1117 1261 1437 1640 1957 2244 2489 2801 3096 3500];
figure,subplot(121),
plot(P,GDP,'bo')
hold on
%% ģ��һ
a=polyfit(P,GDP,2)
GDP1 = a(1,1)*P.^2+a(1,2)*P+a(1,3);
error1 = sum(abs(GDP-GDP1))   % ���
plot(P,GDP1,'rs')
xlabel('���ۣ�Ԫ��')
ylabel('GDP')
%% ģ�Ͷ�
a=polyfit(GDP,P,2)
P1 = a(1,1)*GDP.^2+a(1,2)*GDP+a(1,3);
error2 = sum(abs(P-P1))   % ���
subplot(122)
plot(GDP,P,'bo')
hold on
plot(GDP,P1,'rs')
ylabel('���ۣ�Ԫ��')
xlabel('GDP')







    


 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')