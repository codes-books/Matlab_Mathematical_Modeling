clc        % ����
clear all; % ɾ��workplace����
close all; % �ص���ʾͼ�δ���
x1 = [1,2,3,4,5,6]
x2 = [1;2;3;4;5;6]
x3 = [1:6]
x4= [1:3;2:4;3:5]

%% ����
clc,clear,close all
x1 = 1;
x2 = 2;
x3 = [x1*i,x1;x2,x2*i*i;]
%% ����2
clc,clear,close all
x1 = [1,2;3,4];
x2 = [2,3;4,5];
x3 = x1 + x2*i

%% sym
clc,clear,close all
x1 = sym('[y,s,w;ysw welcome you!]')
x2 = sym('[1,2,3,ysw;SWJTU YuShengWei welcome you!]')
x3 = sym('YuShengWei');
x4 = sym('HuBei_Province');
x5 = sym('SWJTU_Engineering_Department');
x6 = [1,2,3;x3,x4,x5;x3,x3,x3]
%% 
clc,clear,close all
format short
x1 = [1/3,pi;sin(pi),2*pi;log(10),exp(2)]
sym(x1)



 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')