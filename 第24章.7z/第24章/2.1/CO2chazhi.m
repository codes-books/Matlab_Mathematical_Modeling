%CO2��ֵ
clc,clear
load CO2.mat
n0=size(CO2);
t=1:n0(1,1);
t(1,n0(1,1)+1)=31;
t(1,n0(1,1)+2)=36;
t=t';
CO2(n0(1,1)+1,1)=1.2636;
CO2(n0(1,1)+2,1)=1.05;
n1=size(CO2);
j=1;
for i=1:36
    CO2CZ(j,1)=interp1(t,CO2,i,'cubic');
    j=j+1;
end
plot(t,CO2,'r')
hold on
plot(1:36,CO2CZ,'o')
Box off
gtext('year+1985')
gtext('CO2�ŷ�ǿ�� tCO2/��ԪGDP')

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')