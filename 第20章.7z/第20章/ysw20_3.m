%1.3�� ���������
clc,clear,close all
x=[839	935	1050	1188	1336	1443	1380	1546	1662
1035	1170	1335	1530	1738	1825	1761	2033	2331
1391	1609	1988	2393	2716	3200	2725	3192	3590
145	212	280	338	413	495	559	611	631
109.08	110.03	110.08	111.31	112.68	114.16	109.63	109.11	107.62
1.8156e+005	1.9622e+005	2.7647e+005	2.7184e+005	3.0196e+005	3.3677e+005	4.2611e+005	4.3436e+005	4.9617e+005
5520.7	5748.6	6622.1	6896	7358.4	7875.2	8837.6	8831.2	9140.7];
x0=minmax(x);
for i=1:7
    for j=1:9
        x1(i,j)=(x(i,j)-x0(i,1))/(x0(i,2)-x0(i,1));
    end
end
data=x1;
n=size(data,1);
for k=1:3
    ck=data(k,:);m1=size(ck,1);
    bj=data(4:n,:);m2=size(bj,1);
    for i=1:m1
        for j=1:m2
             t(j,:)=bj(j,:)-ck(i,:);
        end
        jc1=min(min(abs(t')));jc2=max(max(abs(t')));
        rho=0.5;
        ksi=(jc1+rho*jc2)./(abs(t)+rho*jc2);
        rt=sum(ksi')/size(ksi,2);
        r(i,:)=rt;
    end
    z(k,:)=r;
end
z
[rs,rind]=sort(z','descend') %�Թ����Ƚ�������

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')