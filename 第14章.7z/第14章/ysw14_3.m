clear;format long
x=0:0.5:4;
c =[3.4250 -0.7304];
y=[30 22.5 15 10.5 6.5 4.5 3 2.5 1.5];
for i=1:9
    y(i)=log(y(i)/c(1));
end
x=[ones(size(x')),x'];
[b,bint,r,rint,stats]=regress(y',x)

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')