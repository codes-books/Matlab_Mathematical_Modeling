clc,clear,close all
Y=0:12;
GDP=[3540 3783 3916 4239 4922 5560 6399 7842 9116 10879 13475 16737 18745];
P=[767 895 995 1117 1261 1437 1640 1957 2244 2489 2801 3096 3500];
figure,
plot(P,GDP,'bo')
hold on
GDP1=zeros(length(GDP),4);
GDP1(:,1)=1;
GDP1(:,2)=GDP;
GDP1(:,3)=Y;
GDP1(:,4)=(Y.^2);
[b,bint,r,rint,stats]=regress(P',GDP1)
P1 = b(1)+b(2)*GDP+b(3)*Y+b(4).*Y.^2;
error = P-P1;
plot(P,P1,'rs')
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')