clc,clear,close all
A=[1   2    4    5
  1/2   1   3   4
  1/4  1/3   1    2
  1/5   1/4  1/2   1];                      
[D,X]=eig(A);
ZD=max(max(X));                      
[m,m]=size(D);                        
p=max(X);
for i=1:m
    if p(i)==ZD
       q=i;
   end
end
z=sum(D);                             
for i=1:m
    for j=1:m
        D(i,j)=D(i,j)/z(j);
    end
end
ZD                                        
B=D(:,q)                                 
RI=[0 0 0.58 0.9 1.12 1.24 1.32 1.41 1.45 1.49 1.51];
CI=(ZD-m)/(m-1)                        
CR=CI/RI(m)     

%% ���Լ�Ȩ�ĳ���
A=[2.3004 1/1.2   1/1.29e-11  1/4.535e-12 35
4.2990    1/2.1   1/2.649e-10 1/7.992e-12  7
2.1686    1/2.9   1/1.743e-10 1/1.074e-11  7];
B=A;
a=size(B,1); % A������
b=size(B,2); % A������
MX=sum(B);   % ÿһ�еĺ�ֵ
for j=1:b    % ��A�����ֵ��׼��
    for i=1:a
        B(i,j)=B(i,j)./MX(j);
    end
end
B;
B1=[0.4 0.2951  0.1834  0.0749  0.0467].*B(1,:);
B2=[0.4 0.2951  0.1834  0.0749  0.0467].*B(2,:);
B3=[0.4 0.2951  0.1834  0.0749  0.0467].*B(3,:);
s=sum(B1)+sum(B2)+sum(B3);
sum(B1)/s*100
sum(B2)/s*100
sum(B3)/s*100

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')