%CO2��ֵ
clc,clear
load mtxfl.mat
n0=size(mtxfl);
mtxfl=zscore(mtxfl);

figure(1),
X=mtxfl(:,2:4);
X=[ones(n0(1,1),1),X];
Y=mtxfl(:,n0(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n0(1,1)
    if i~=1
        Cmtxfl(j,:)=mtxfl(i,:);
        j=j+1;
    end
end
figure(2),
n1=size(Cmtxfl);
X=Cmtxfl(:,2:4);
X=[ones(n1(1,1),1),X];
Y=Cmtxfl(:,n1(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')