%���ںϲ�
clc,clear;
load xsum.mat
load xuekepj.mat
n0=size(xsum);
j=1;
for i=1:n0(1,1)
    if xsum(i,3)~=0
        zq(j,:)=xsum(i,:);
        j=j+1;
    end
end
n1=size(zq);
%08��������
for i=1:n1(1,1)
    fpfa09(i,1)=zq(i,3);
    fpfa09(i,2)=zq(i,16);
    fpfa09(i,3)=zq(i,25);
    fpfa09(i,4)=zq(i,31);
    fpfa09(i,5)=zq(i,37);
    fpfa09(i,6)=xuekepj(i,1);
    fpfa09(i,7)=zq(i,6);
end
for i=1:n1(1,1)
    if fpfa09(i,1)==1
        fpfa09(i,1)=7;
    end
    if fpfa09(i,1)==2
        fpfa09(i,1)=6;
    end
    if fpfa09(i,1)==3
        fpfa09(i,1)=5; 
    end
    if fpfa09(i,1)==4
        fpfa09(i,1)=4;
    end
    if fpfa09(i,1)==5
        fpfa09(i,1)=3; 
    end
    if fpfa09(i,1)==6
        fpfa09(i,1)=2;
    end
    if fpfa09(i,1)==7
        fpfa09(i,1)=1; 
    end
end

a=mean(fpfa09);
% %a=mean(a');
a1=std(fpfa09);
a2=fpfa09(:,7);

fpfa09=zscore(fpfa09);
n2=size(fpfa09);
for i=1:n2(1,1)
    Byucers(i,1)=-0.3322+0.39*fpfa09(i,1)+0.0219*fpfa09(i,2)+0.0754*fpfa09(i,3)-0.0026*fpfa09(i,4)+0.0084*fpfa09(i,5)+0.0172*fpfa09(i,6);
end
for i=1:n2(1,1)
    yucers(i,1)=Byucers(i,1)*a1(1,7)+a(1,7);
    yucers(i,1)=floor(yucers(i,1))+1;
    yucers(i,2)=a2(i,1);
end
plot(1:n2(1,1),yucers(:,1))
hold on
plot(1:n2(1,1),yucers(:,2))  
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')