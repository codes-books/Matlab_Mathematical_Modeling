%���ںϲ�
clc,clear;
load xsum.mat
n0=size(xsum);
j=1;
for i=1:n0(1,1)
    if xsum(i,3)~=0
        zq(j,:)=xsum(i,:);
        j=j+1;
    end
end
n1=size(zq);
%11��������
for i=1:n1(1,1)
    fpfa11(i,1)=zq(i,3);
    fpfa11(i,2)=zq(i,18);
    fpfa11(i,3)=zq(i,27);
    fpfa11(i,4)=zq(i,33);
    fpfa11(i,5)=zq(i,39);
    fpfa11(i,6)=zq(i,7);
end
for i=1:n1(1,1)
    if fpfa11(i,1)==1
        fpfa11(i,1)=7;
    end
    if fpfa11(i,1)==2
        fpfa11(i,1)=6;
    end
    if fpfa11(i,1)==3
        fpfa11(i,1)=5; 
    end
    if fpfa11(i,1)==4
        fpfa11(i,1)=4;
    end
    if fpfa11(i,1)==5
        fpfa11(i,1)=3; 
    end
    if fpfa11(i,1)==6
        fpfa11(i,1)=2;
    end
    if fpfa11(i,1)==7
        fpfa11(i,1)=1; 
    end
end
n2=size(fpfa11);
for i=1:n2(1,1)
    yucers(i,1)=0.0753+0.5448*fpfa11(i,1)+0.0472*fpfa11(i,2)+0.0328*fpfa11(i,3)+0.1366*fpfa11(i,4)+0.045*fpfa11(i,5);
    yucers(i,1)=floor(yucers(i,1))+1;
    yucers(i,2)=fpfa11(i,6);
end
plot(1:n2(1,1),yucers(:,1))
hold on
plot(1:n2(1,1),yucers(:,2))  









 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')