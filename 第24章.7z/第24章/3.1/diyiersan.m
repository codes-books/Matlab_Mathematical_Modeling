%CO2��ֵ
clc,clear
load mtxfl.mat
n0=size(mtxfl);
a=mean(mtxfl);
% %a=mean(a');
a1=std(mtxfl);
% %b=std(b');
% for i=1:n0(1,2)
%     for j=1:n0(1,1)
%         mstdata(j,i)=(mstdata(j,i)-a(1,i))/b(1,i);
%     end
% end
% 

% mstdata=zscore(mstdata);

n1=size(xm);
for i=1:n1(1,1)
    for j=1:n1(1,2)
        xm1(i,j)=xm(i,j)*a1(1,j+1)+a(1,j+1);
    end
end

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')