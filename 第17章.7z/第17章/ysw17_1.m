clc,clear,close all
x=[0.6,0.67,0.6];
ca=[0.1,0.335,0.1];
ca1=x-ca./sqrtm((-log(0.1)))






 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')