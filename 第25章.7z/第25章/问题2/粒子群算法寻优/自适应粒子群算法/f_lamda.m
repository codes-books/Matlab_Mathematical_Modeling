function y=f_lamda(lamda,r)
% f(��)
y= (2/(r+1)).^(1/(r-1))*q_lamda(lamda,r)*(lamda+1/lamda);
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')