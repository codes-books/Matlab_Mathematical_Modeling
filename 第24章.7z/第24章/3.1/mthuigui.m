%CO2��ֵ
clc,clear
load mtxfl.mat
n0=size(mtxfl);

figure(1),
X=mtxfl(:,2:4);
X=[ones(n0(1,1),1),X];
Y=mtxfl(:,1); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n0(1,1)
    if i~=3&&i~=11
        Cmtxfl(j,:)=mtxfl(i,:);
        j=j+1;
    end
end
figure(2),
n1=size(Cmtxfl);
X=Cmtxfl(:,2:4);
X=[ones(n1(1,1),1),X];
Y=Cmtxfl(:,1); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
n2=size(Cmtxfl);
for i=1:n2(1,1)
    if i~=1&&i~=2
        CCmtxfl(j,:)=Cmtxfl(i,:);
        j=j+1;
    end
end
figure(3),
n3=size(CCmtxfl);
X=CCmtxfl(:,2:4);
X=[ones(n3(1,1),1),X];
Y=CCmtxfl(:,1); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
n2=size(CCmtxfl);
for i=1:n2(1,1)
    if i~=1
        CCCmtxfl(j,:)=CCmtxfl(i,:);
        j=j+1;
    end
end
figure(3),
n3=size(CCCmtxfl);
X=CCCmtxfl(:,2:4);
X=[ones(n3(1,1),1),X];
Y=CCCmtxfl(:,1); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
n2=size(CCCmtxfl);
for i=1:n2(1,1)
    if i~=1
        CCCCmtxfl(j,:)=CCCmtxfl(i,:);
        j=j+1;
    end
end
figure(4),
n3=size(CCCCmtxfl);
X=CCCCmtxfl(:,2:4);
X=[ones(n3(1,1),1),X];
Y=CCCCmtxfl(:,1); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
n2=size(CCCCmtxfl);
for i=1:n2(1,1)
    if i~=1
        CCCCCmtxfl(j,:)=CCCCmtxfl(i,:);
        j=j+1;
    end
end
figure(5),
n3=size(CCCCCmtxfl);
X=CCCCCmtxfl(:,2:4);
X=[ones(n3(1,1),1),X];
Y=CCCCCmtxfl(:,1); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')