function [p15,lamda15]=P_lam(Wg15, P225, lamda225, A225, P125, lamda125, A125, km, T15, r)
% �������������ѹ P  �Լ� ��

syms lamda15;
A15 = A225 + A125;
% q_lamda(lamda15, r)= ((r+1)/2).^(1/(r-1))*lamda15*(1-(r-1)/(r+1)*lamda15^2)^(1/(r-1));
% p15 = ( Wg15 *sqrt(T15) /km /A15 ./ ((r+1)/2).^(1/(r-1))*lamda15*(1-(r-1)/(r+1)*lamda15^2)^(1/(r-1)) );
% 
% f_lamda(lamda225,r)= (2/(r+1)).^(1/(r-1))*((r+1)/2).^(1/(r-1))*lamda225*(1-(r-1)/(r+1)*lamda225^2)^(1/(r-1))*(lamda225+1/lamda225)
% f_lamda(lamda15,r) = (2/(r+1)).^(1/(r-1))*((r+1)/2).^(1/(r-1))*lamda15*(1-(r-1)/(r+1)*lamda15^2)^(1/(r-1))*(lamda15+1/lamda15)

% y1 = P225* (2/(r+1)).^(1/(r-1))*((r+1)/2).^(1/(r-1))*lamda225*(1-(r-1)/(r+1)*lamda225^2)^(1/(r-1))*(lamda225+1/lamda225)*A225 +...
%     P125*(2/(r+1)).^(1/(r-1))*((r+1)/2).^(1/(r-1))*lamda125*(1-(r-1)/(r+1)*lamda125^2)^(1/(r-1))*(lamda125+1/lamda125)*A125 -...
%     ( Wg15 *sqrt(T15) /km /A15 ./ ((r+1)/2).^(1/(r-1))*lamda15*(1-(r-1)/(r+1)*lamda15^2)^(1/(r-1)) ) *(2/(r+1)).^(1/(r-1))*((r+1)/2).^(1/(r-1))*lamda15*(1-(r-1)/(r+1)*lamda15^2)^(1/(r-1))*(lamda15+1/lamda15)*A15;

ylamda = @(lamda15)abs( P225* (2/(r+1)).^(1/(r-1))*((r+1)/2).^(1/(r-1))*lamda225*(1-(r-1)/(r+1)*lamda225^2)^(1/(r-1))*(lamda225+1/lamda225)*A225 +...
    P125*(2/(r+1)).^(1/(r-1))*((r+1)/2).^(1/(r-1))*lamda125*(1-(r-1)/(r+1)*lamda125^2)^(1/(r-1))*(lamda125+1/lamda125)*A125 -...
    ( Wg15 *sqrt(T15) /km /A15 ./ ((r+1)/2).^(1/(r-1))*lamda15*(1-(r-1)/(r+1)*lamda15^2)^(1/(r-1)) ) *(2/(r+1)).^(1/(r-1))*((r+1)/2).^(1/(r-1))*lamda15*(1-(r-1)/(r+1)*lamda15^2)^(1/(r-1))*(lamda15+1/lamda15)*A15 );

lb = -0.01; % ����
ub = 3; % ����
lamda15 = fmincon(ylamda,0.1,[],[],[],[],lb,ub,[],optimset('Algorithm','SQP','Disp','none'));
p15 = Wg15 *sqrt(T15) /km /A15 ./ q_lamda(lamda15, r);
% y=[p15,lamda15];




 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')