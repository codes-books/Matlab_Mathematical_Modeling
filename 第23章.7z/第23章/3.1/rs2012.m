%���ںϲ�
clc,clear;
load xsum.mat
n0=size(xsum);
j=1;
for i=1:n0(1,1)
    if xsum(i,3)~=0
        zq(j,:)=xsum(i,:);
        j=j+1;
    end
end
n1=size(zq);
%08��������
for i=1:n1(1,1)
    fpfa12(i,1)=zq(i,3);
    fpfa12(i,2)=zq(i,19);
    fpfa12(i,3)=zq(i,28);
    fpfa12(i,4)=zq(i,34);
    fpfa12(i,5)=zq(i,40);
end
for i=1:n1(1,1)
    if fpfa12(i,1)==1
        fpfa12(i,1)=7;
    end
    if fpfa12(i,1)==2
        fpfa12(i,1)=6;
    end
    if fpfa12(i,1)==3
        fpfa12(i,1)=5; 
    end
    if fpfa12(i,1)==4
        fpfa12(i,1)=4;
    end
    if fpfa12(i,1)==5
        fpfa12(i,1)=3; 
    end
    if fpfa12(i,1)==6
        fpfa12(i,1)=2;
    end
    if fpfa12(i,1)==7
        fpfa12(i,1)=1; 
    end
end
n2=size(fpfa12);

figure(1),
X=fpfa12(:,1:5);
X=[ones(n2(1,1),1),X];
Y=fpfa12(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)


 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')