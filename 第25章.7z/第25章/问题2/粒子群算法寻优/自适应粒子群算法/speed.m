function V=speed(Ma,r,R,T)

V=Ma*sqrt(r*R*T);
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')