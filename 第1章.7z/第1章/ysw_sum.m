function y = ysw_sum(a,b)
y = a+b;
end

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')