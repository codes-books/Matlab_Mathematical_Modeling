%CO2��ֵ
clc,clear
load mtxfl.mat
n0=size(mtxfl);
mtxfl=zscore(mtxfl);
j=1;
rou=0.95;
for i=2:n0(1,1)
    mtxfl1(j,2)=mtxfl(i,2)-rou*mtxfl(i-1,2);
    mtxfl1(j,3)=mtxfl(i,3)-rou*mtxfl(i-1,3);
    mtxfl1(j,4)=mtxfl(i,4)-rou*mtxfl(i-1,4);
    mtxfl1(j,5)=mtxfl(i,5)-rou*mtxfl(i-1,5);
    j=j+1;
end
mtxfl=[];
mtxfl=mtxfl1;
n0=size(mtxfl);
figure(1),
X=mtxfl(:,2:4);
X=[ones(n0(1,1),1),X];
Y=mtxfl(:,n0(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n0(1,1)
    if i~=1&&i~=2&&i~=10
        Cmtxfl(j,:)=mtxfl(i,:);
        j=j+1;
    end
end
figure(2),
n1=size(Cmtxfl);
X=Cmtxfl(:,2:4);
X=[ones(n1(1,1),1),X];
Y=Cmtxfl(:,n1(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
n0=size(Cmtxfl);
j=1;
for i=1:n0(1,1)
    if i~=7&&i~=8
        CCmtxfl(j,:)=Cmtxfl(i,:);
        j=j+1;
    end
end
figure(3),
n1=size(CCmtxfl);
X=CCmtxfl(:,2:4);
X=[ones(n1(1,1),1),X];
Y=CCmtxfl(:,n1(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
n0=size(CCmtxfl);
j=1;
for i=1:n0(1,1)
    if i~=6
        CCCmtxfl(j,:)=CCmtxfl(i,:);
        j=j+1;
    end
end
figure(4),
n1=size(CCCmtxfl);
X=CCCmtxfl(:,2:4);
X=[ones(n1(1,1),1),X];
Y=CCCmtxfl(:,n1(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
n0=size(CCCmtxfl);
j=1;
for i=1:n0(1,1)
    if i~=9
        CCCCmtxfl(j,:)=CCCmtxfl(i,:);
        j=j+1;
    end
end
figure(5),
n1=size(CCCCmtxfl);
X=CCCCmtxfl(:,2:4);
X=[ones(n1(1,1),1),X];
Y=CCCCmtxfl(:,n1(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
n0=size(CCCCmtxfl);
j=1;
for i=1:n0(1,1)
    if i~=6
        CCCCCmtxfl(j,:)=CCCCmtxfl(i,:);
        j=j+1;
    end
end
figure(6),
n1=size(CCCCCmtxfl);
X=CCCCCmtxfl(:,2:4);
X=[ones(n1(1,1),1),X];
Y=CCCCCmtxfl(:,n1(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')