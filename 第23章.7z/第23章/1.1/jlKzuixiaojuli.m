%���ںϲ�
clc,clear;
load jlKO.mat
n0=size(OKD);
jlKzxjl(1,1)=min(OKD(n0(1,1)-1,1:n0(1,2)-2));
for i=1:n0(1,2)-2
    if jlKzxjl(1,1)==OKD(n0(1,1)-1,i);
       jlKzxjl(1,2)=i;
    end
end
jlKzxjl(2,1)=min(OKD(n0(1,1),1:n0(1,2)-2));
for i=1:n0(1,2)-2
    if jlKzxjl(2,1)==OKD(n0(1,1),i);
       jlKzxjl(2,2)=i;
    end
end



 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')