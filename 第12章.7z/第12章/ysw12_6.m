clc,clear
load('data.mat')  % ��������
yx =[4.81;4.8;4.73;4.7;4.7;4.73;4.75;4.75;5.43;5.78;5.85;5.88;5.93];
yt=yx; 
n=length(yt);
alpha=[0.1 0.3 0.9];
m=length(alpha);
yhat(1,1:m)=(yt(1)+yt(2))/2;
for i=2:n
    yhat(i,:)=alpha*yt(i-1)+(1-alpha).*yhat(i-1,:);
end
yhat;                                     % Ԥ��ֵ
err=sqrt(mean((repmat(yt,1,m)-yhat).^2))  % Ԥ������ܺ�
yhat114=alpha*yt(n)+(1-alpha).*yhat(n,:)  % Ԥ����һʱ��ֵ

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')