clc,clear
load biao3.mat
load diyiz.mat
load nibian.mat
n0=size(diyiz);
n1=size(nibian);
k=1;

i=2;
m=1;p=1;p1=1;p2=1;p3=1;
%123
nn=1;j=1;
n11=floor(1.77032/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))));
n12=floor(1.77032-n11*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3)))/(biao3(diyiz(i,j),7)*10^(-3)));
n13=floor(1.77032-n11*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3)))/(biao3(diyiz(i,j+1),7)*10^(-3)));
n14=floor(1.77032-n11*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3)))/(biao3(diyiz(i,j+2),7)*10^(-3)));

n2=floor(3.35751/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))));
n21=floor((3.35751-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))))/(biao3(diyiz(i,j),7)*10^(-3)));
n22=floor((3.35751-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))))/(biao3(diyiz(i,j+1),7)*10^(-3)));
n23=floor((3.35751-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+1),7)*10^(-3))+(biao3(diyiz(i,j+2),7)*10^(-3))))/(biao3(diyiz(i,j+2),7)*10^(-3)));

N=n11+n2;%���ֵ����������
N1=n12+n21;%�����һ�ֵ�ذ�����
N2=n13+n22;%����ڶ��ֵ�ذ�����
N3=n14+n23;%��������ֵ�ذ�����

fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+1),5)+biao3(diyiz(i,j+2),5))*N;%������
fadian(k,m+3)=fadian(k,m)+N1*biao3(diyiz(i,j),5);%������1
fadian(k,m+6)=fadian(k,m)+N2*biao3(diyiz(i,j+1),5);%������2
fadian(k,m+9)=fadian(k,m)+N3*biao3(diyiz(i,j+2),5);%������3

fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+1),6)+biao3(diyiz(i,j+2),6))*N;%��������
fadian(k,m+1+3)=fadian(k,m+1)+N1*biao3(diyiz(i,j),6);%��������1
fadian(k,m+1+6)=fadian(k,m+1)+N2*biao3(diyiz(i,j+1),6);%��������2
fadian(k,m+1+9)=fadian(k,m+1)+N3*biao3(diyiz(i,j+2),6);%��������3

for l=1:n1(1,1)
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+2),2))*N) < nibian(l,1)
        a1(p,1)=nibian(l,2);
        p=p+1;
    end
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+2),2))*N+N1*biao3(diyiz(i,j),2)) < nibian(l,1)
        a2(p1,1)=nibian(l,2);
        p1=p1+1;
    end
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+2),2))*N+N2*biao3(diyiz(i,j+1),2)) < nibian(l,1)
        a3(p2,1)=nibian(l,2);
        p2=p2+1;
    end
    if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+1),2)+biao3(diyiz(i,j+2),2))*N+N3*biao3(diyiz(i,j+2),2)) < nibian(l,1)
        a4(p3,1)=nibian(l,2);
        p3=p3+1;
    end
end
fadian(k,m+2)=min(a1);%���������
fadian(k,m+2+3)=min(a2);%���������1
fadian(k,m+2+6)=min(a3);%���������2
fadian(k,m+2+9)=min(a4);%���������3
k=k+1;

n=size(fadian);
k=1;
for i=1:n(1,1)
    for j=1:n(1,2)
        if j==1
            a(k,1)=fadian(i,j);
        end
        if j==2
            a(k,2)=fadian(i,j);
        end
        if j==3
            a(k,3)=fadian(i,j);
        end
        if j==4
            a(k+1,1)=fadian(i,j);
        end
        if j==5
            a(k+1,2)=fadian(i,j);
        end
        if j==6
            a(k+1,3)=fadian(i,j);
        end
        if j==7
            a(k+2,1)=fadian(i,j);
         end
        if j==8
            a(k+2,2)=fadian(i,j); 
        end
        if j==9
            a(k+2,3)=fadian(i,j);
        end 
        if j==10
            a(k+3,1)=fadian(i,j);
         end
        if j==11
            a(k+3,2)=fadian(i,j); 
        end
        if j==12
            a(k+3,3)=fadian(i,j);
        end 
    end
    k=k+4;
end
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')