clear;clc;
V=[0.9287 0.8808 0.9055 1.1806 1.3378 1.2097 19.8944 19.8944 19.8944];
s=[4 pi*0.2^2];
for i=1:6
   fengliang(i)=V(i)*s(1);
end
for i=7:9
    fengliang(i)=V(i)*s(2);
end
fengliang*60

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')