function y=pi_lamda(lamda,r)
% ��(��)
y= (1-(r-1)/(r+1)*lamda^2)^(r/(r-1));
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')