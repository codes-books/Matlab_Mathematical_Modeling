clc,clear
load A1.mat %̫��ʵ�ʷ�λ��
load alpha.mat%̫���߶Ƚ�
load yiyue1.mat%1��1��̫������ǿ��
load fulu4.mat
syms beta r;
n=size(yiyue1);
n0=size(fulu4);
% m=1;
% for i=1:365
%     for j=(24*i-16):(24*i-6)
%         for k=1:n0(1,2)
%             a(m,k)=fulu4(j,k);  
%         end
%         m=m+1;
%     end
% end
% n=size(a);
n1=90;n2=180;
QT(n1,n2)=[0];
k=1;
% yiyue1=[];
% yiyue1=a;
kk=1;
for N=10:56
    for beta=1:N%betaΪ������ǣ���ذ�ĳ���
        for r=1:n2%rΪ��ذ�ĳ���
            for i=1:n(1,1)
                QT(beta,r)=QT(beta,r)-(yiyue1(i,3)*sin((alpha(k,1)+beta)*2*pi/360)* cos((A1(k,1)+r)*2*pi/360)+yiyue1(i,2)*(1+cos(beta*2*pi/360))/2+0.2*yiyue1(i,1)*(1-cos(beta*2*pi/360))/2);
                k=k+1;
                if k>=8
                    k=1;
                end
            end
        end
    end
    a=max(QT);
    b=max(a');
    for i=1:n1
        for j=1:n2
            if QT(i,j)==b;
                betaj(kk)=i;
                r(kk)=j;
                kk=kk+1;
            end
        end
    end
end

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')