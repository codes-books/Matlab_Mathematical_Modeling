%���ںϲ�
clc,clear;
load xsum.mat
load xuekepj.mat
n0=size(xsum);
j=1;
for i=1:n0(1,1)
    if xsum(i,3)~=0
        zq(j,:)=xsum(i,:);
        j=j+1;
    end
end
n1=size(zq);
%08��������
for i=1:n1(1,1)
    fpfa10(i,1)=zq(i,3);
    fpfa10(i,2)=zq(i,17);
    fpfa10(i,3)=zq(i,26);
    fpfa10(i,4)=zq(i,32);
    fpfa10(i,5)=zq(i,38);
    fpfa10(i,6)=xuekepj(i,1);
    fpfa10(i,7)=zq(i,7);
end
for i=1:n1(1,1)
    if fpfa10(i,1)==1
        fpfa10(i,1)=7;
    end
    if fpfa10(i,1)==2
        fpfa10(i,1)=6;
    end
    if fpfa10(i,1)==3
        fpfa10(i,1)=5; 
    end
    if fpfa10(i,1)==4
        fpfa10(i,1)=4;
    end
    if fpfa10(i,1)==5
        fpfa10(i,1)=3; 
    end
    if fpfa10(i,1)==6
        fpfa10(i,1)=2;
    end
    if fpfa10(i,1)==7
        fpfa10(i,1)=1; 
    end
end

a=mean(fpfa10);
% %a=mean(a');
a1=std(fpfa10);

fpfa10=zscore(fpfa10);%��׼������
n2=size(fpfa10);
% Bfpfa08=zscore(fpfa08(:,1:n2(1,2)-1));  % ��׼�����ݾ���
% Bfpfa08(:,n2(1,2))=fpfa08(:,n2(1,2)); 

% figure(1),
% subplot(2,3,1)
% plot(fpfa08(:,1),fpfa08(:,6));%����
% subplot(2,3,2)
% plot(fpfa08(:,2),fpfa08(:,6));%Ӣ������
% subplot(2,3,3)
% plot(fpfa08(:,2),fpfa08(:,6));%��������
% subplot(2,2,3)
% plot(fpfa08(:,4),fpfa08(:,6));%ר����
% subplot(2,2,4)
% plot(fpfa08(:,5),fpfa08(:,6));%�񽱸���

figure(1),
X=fpfa10(:,1:6);
X=[ones(n2(1,1),1),X];
Y=fpfa10(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n1(1,1)
    if i~=33&&i~=41&&i~=91&&i~=113&&i~=131&&i~=132&&i~=143&&i~=167&&i~=215&&i~=213&&i~=224&&i~=242&&i~=251&&i~=255&&i~=257&&i~=252&&i~=266&&i~=261&&i~=264&&i~=269
        Cfpfa10(j,:)=fpfa10(i,:);
        j=j+1;
    end
end
figure(2),
n3=size(Cfpfa10);
X=Cfpfa10(:,1:6);
X=[ones(n3(1,1),1),X];
Y=Cfpfa10(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n3(1,1)
    if i~=5&&i~=76&&i~=96&&i~=111&&i~=130&&i~=136&&i~=151&&i~=166&&i~=158&&i~=165&&i~=190&&i~=197&&i~=205&&i~=210&&i~=218&&i~=231&&i~=233&&i~=238&&i~=244&&i~=262&&i~=303&&i~=313
        CCfpfa10(j,:)=Cfpfa10(i,:);
        j=j+1;
    end
end
figure(3),
n3=size(CCfpfa10);
X=CCfpfa10(:,1:6);
X=[ones(n3(1,1),1),X];
Y=CCfpfa10(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n3(1,1)
    if i~=27&&i~=26&&i~=84&&i~=88&&i~=148&&i~=149&&i~=184&&i~=195&&i~=196&&i~=206&&i~=209&&i~=253&&i~=259
        CCCfpfa10(j,:)=CCfpfa10(i,:);
        j=j+1;
    end
end
figure(4),
n3=size(CCCfpfa10);
X=CCCfpfa10(:,1:6);
X=[ones(n3(1,1),1),X];
Y=CCCfpfa10(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n3(1,1)
    if i~=105&&i~=108&&i~=110&&i~=112&&i~=209&&i~=240
        CCCCfpfa10(j,:)=CCCfpfa10(i,:);
        j=j+1;
    end
end
figure(5),
n3=size(CCCCfpfa10);
X=CCCCfpfa10(:,1:6);
X=[ones(n3(1,1),1),X];
Y=CCCCfpfa10(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n3(1,1)
    if i~=83&&i~=90&&i~=95&&i~=117&&i~=113&&i~=135&&i~=117&&i~=148&&i~=153&&i~=170&&i~=174&&i~=215
        CCCCCfpfa10(j,:)=CCCCfpfa10(i,:);
        j=j+1;
    end
end
figure(6),
n3=size(CCCCCfpfa10);
X=CCCCCfpfa10(:,1:6);
X=[ones(n3(1,1),1),X];
Y=CCCCCfpfa10(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

%ɾ��һЩ��
j=1;
for i=1:n3(1,1)
    if i~=3&&i~=37&&i~=60&&i~=76&&i~=191&&i~=203&&i~=210
        CCCCCCfpfa10(j,:)=CCCCCfpfa10(i,:);
        j=j+1;
    end
end
figure(7),
n3=size(CCCCCCfpfa10);
X=CCCCCCfpfa10(:,1:6);
X=[ones(n3(1,1),1),X];
Y=CCCCCCfpfa10(:,n2(1,2)); 
[b,bint,r,rint,s]=regress(Y,X);
rcoplot(r,rint)

% 
% %ɾ��һЩ��
% j=1;
% for i=1:n3(1,1)
%     if i~=52&&i~=17&&i~=83&&i~=121&&i~=245&&i~=232&&i~=174&&i~=148&&i~=129&&i~=115&&i~=109&&i~=100&&i~=97
%         CCCCCCCfpfa08(j,:)=CCCCCCfpfa08(i,:);
%         j=j+1;
%     end
% end
% figure(8),
% n3=size(CCCCCCCfpfa08);
% X=CCCCCCCfpfa08(:,1:5);
% X=[ones(n3(1,1),1),X];
% Y=CCCCCCCfpfa08(:,n2(1,2)); 
% [b,bint,r,rint,s]=regress(Y,X);
% rcoplot(r,rint)
% 
% %ɾ��һЩ��
% j=1;
% for i=1:n3(1,1)
%     if i~=3&&i~=5&&i~=12&&i~=14&&i~=40&&i~=46&&i~=53&&i~=66&&i~=73&&i~=75&&i~=139&&i~=151&&i~=154&&i~=156&&i~=159&&i~=214&&i~=220&&i~=222&&i~=224&&i~=206&&i~=202&&i~=165&&i~=115
%         CCCCCCCCfpfa08(j,:)=CCCCCCCfpfa08(i,:);
%         j=j+1;
%     end
% end
% figure(9),
% n3=size(CCCCCCCCfpfa08);
% X=CCCCCCCCfpfa08(:,1:5);
% X=[ones(n3(1,1),1),X];
% Y=CCCCCCCCfpfa08(:,n2(1,2)); 
% [b,bint,r,rint,s]=regress(Y,X);
% rcoplot(r,rint)
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')