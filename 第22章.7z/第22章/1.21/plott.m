clc,clear
load plott.mat
% plot(1:14,plott(:,1),'.')
plot(1:14,plott(:,2),'.')
hold on
plot(1:0.01:14,80)
 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')