%���ںϲ�
clc,clear;
load jlAO.mat
n0=size(OAD);
for i=1:n0(1,1)
    jlAzxjl(1,1)=min(OAD(n0(1,1),1:n0(1,2)-1));
end
for i=1:n0(1,2)-1
    if jlAzxjl(1,1)==OAD(n0(1,1),i);
       jlAzxjl(1,2)=i;
    end
end




 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')