clc,clear
load biao3.mat
load diyiz.mat
load nibian.mat
n0=size(diyiz);
n1=size(nibian);
k=1;
c=3.91622;w=0;
i=1;%��һ�ַ���
m=1;p=1;p1=1;p2=1;
for j=1:9
        for nn=1:9-j
            n2=floor(c/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))));
            n21=floor(w/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))));
            n22=floor((c-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j),7)*10^(-3)))+floor((w-n21*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j),7)*10^(-3)));
            n222=floor((c-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j+nn),7)*10^(-3)))+floor((w-n21*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j+nn),7)*10^(-3)));
            
            n2=n2+n21;
            fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+nn),5))*n2;%������
            fadian(k,m+3)=fadian(k,m)+biao3(diyiz(i,j),5)*n22; %������2
            fadian(k,m+3+3)=fadian(k,m)+biao3(diyiz(i,j+nn),5)*n222;%������3

            fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+nn),6))*n2;%��������
            fadian(k,m+1+3)=fadian(k,m+1)+biao3(diyiz(i,j),6)*n22;%��������2
            fadian(k,m+1+3+3)=fadian(k,m+1)+biao3(diyiz(i,j+nn),6)*n222;%��������3

            for l=1:n1(1,1)
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2) < nibian(l,1)
                    a1(p,1)=nibian(l,2);
                    p=p+1;
                end
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2+biao3(diyiz(i,j),2)*n22) < nibian(l,1)
                    a2(p1,1)=nibian(l,2);
                    p1=p1+1;
                end
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2+biao3(diyiz(i,j+nn),2)*n222) < nibian(l,1)
                    a3(p2,1)=nibian(l,2);
                    p2=p2+1;
                end
            end
            fadian(k,m+2)=min(a1);%���������
            fadian(k,m+2+3)=min(a2);%���������
            fadian(k,m+2+3+3)=min(a3);%���������
            k=k+1;
        end
        k=k+1;
end
  

i=2;%�ڶ��ַ���
m=1;p=1;p1=1;p2=1;
for j=1:3
        for nn=1:3-j
            n2=floor(c/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))));
            n21=floor(w/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))));
            n22=floor((c-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j),7)*10^(-3)))+floor((w-n21*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j),7)*10^(-3)));
            n222=floor((c-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j+nn),7)*10^(-3)))+floor((w-n21*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j+nn),7)*10^(-3)));
           
            n2=n2+n21;
            fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+nn),5))*n2;%������
            fadian(k,m+3)=fadian(k,m)+biao3(diyiz(i,j),5)*n22; %������2
            fadian(k,m+3+3)=fadian(k,m)+biao3(diyiz(i,j+nn),5)*n222;%������3

            fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+nn),6))*n2;%��������
            fadian(k,m+1+3)=fadian(k,m+1)+biao3(diyiz(i,j),6)*n22;%��������2
            fadian(k,m+1+3+3)=fadian(k,m+1)+biao3(diyiz(i,j+nn),6)*n222;%��������3

            for l=1:n1(1,1)
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2) < nibian(l,1)
                    a1(p,1)=nibian(l,2);
                    p=p+1;
                end
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2+biao3(diyiz(i,j),2)*n22) < nibian(l,1)
                    a2(p1,1)=nibian(l,2);
                    p1=p1+1;
                end
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2+biao3(diyiz(i,j+nn),2)*n222) < nibian(l,1)
                    a3(p2,1)=nibian(l,2);
                    p2=p2+1;
                end
            end
            fadian(k,m+2)=min(a1);%���������
            fadian(k,m+2+3)=min(a2);%���������
            fadian(k,m+2+3+3)=min(a3);%���������
            k=k+1;
        end
        k=k+1;
end

i=3;%�����ַ���
m=1;p=1;p1=1;p2=1;
for j=1
        for nn=1
            n2=floor(c/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))));
            n21=floor(w/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))));
            n22=floor((c-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j),7)*10^(-3)))+floor((w-n21*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j),7)*10^(-3)));
            n222=floor((c-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j+nn),7)*10^(-3)))+floor((w-n21*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j+nn),7)*10^(-3)));
            
            n2=n2+n21;
            fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+nn),5))*n2;%������
            fadian(k,m+3)=fadian(k,m)+biao3(diyiz(i,j),5)*n22; %������2
            fadian(k,m+3+3)=fadian(k,m)+biao3(diyiz(i,j+nn),5)*n222;%������3

            fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+nn),6))*n2;%��������
            fadian(k,m+1+3)=fadian(k,m+1)+biao3(diyiz(i,j),6)*n22;%��������2
            fadian(k,m+1+3+3)=fadian(k,m+1)+biao3(diyiz(i,j+nn),6)*n222;%��������3

            for l=1:n1(1,1)
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2) < nibian(l,1)
                    a1(p,1)=nibian(l,2);
                    p=p+1;
                end
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2+biao3(diyiz(i,j),2)*n22) < nibian(l,1)
                    a2(p1,1)=nibian(l,2);
                    p1=p1+1;
                end
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2+biao3(diyiz(i,j+nn),2)*n222) < nibian(l,1)
                    a3(p2,1)=nibian(l,2);
                    p2=p2+1;
                end
            end
            fadian(k,m+2)=min(a1);%���������
            fadian(k,m+2+3)=min(a2);%���������
            fadian(k,m+2+3+3)=min(a3);%���������
            k=k+1;
        end
        k=k+1;
end

i=4;%�����ַ���
m=1;p=1;p1=1;p2=1;
for j=1:2
        for nn=1:2-j
            n2=floor(c/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))));
            n21=floor(w/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))));
            n22=floor((c-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j),7)*10^(-3)))+floor((w-n21*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j),7)*10^(-3)));
            n222=floor((c-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j+nn),7)*10^(-3)))+floor((w-n21*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j+nn),7)*10^(-3)));
           
            n2=n2+n21;
            fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+nn),5))*n2;%������
            fadian(k,m+3)=fadian(k,m)+biao3(diyiz(i,j),5)*n22; %������2
            fadian(k,m+3+3)=fadian(k,m)+biao3(diyiz(i,j+nn),5)*n222;%������3

            fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+nn),6))*n2;%��������
            fadian(k,m+1+3)=fadian(k,m+1)+biao3(diyiz(i,j),6)*n22;%��������2
            fadian(k,m+1+3+3)=fadian(k,m+1)+biao3(diyiz(i,j+nn),6)*n222;%��������3

            for l=1:n1(1,1)
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2) < nibian(l,1)
                    a1(p,1)=nibian(l,2);
                    p=p+1;
                end
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2+biao3(diyiz(i,j),2)*n22) < nibian(l,1)
                    a2(p1,1)=nibian(l,2);
                    p1=p1+1;
                end
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2+biao3(diyiz(i,j+nn),2)*n222) < nibian(l,1)
                    a3(p2,1)=nibian(l,2);
                    p2=p2+1;
                end
            end
            fadian(k,m+2)=min(a1);%���������
            fadian(k,m+2+3)=min(a2);%���������
            fadian(k,m+2+3+3)=min(a3);%���������
            k=k+1;
        end
        k=k+1;
end
i=5;%�����ַ���
m=1;p=1;p1=1;p2=1;
for j=1:2
        for nn=1:2-j
            n2=floor(c/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))));
            n21=floor(w/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))));
            n22=floor((c-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j),7)*10^(-3)))+floor((w-n21*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j),7)*10^(-3)));
            n222=floor((c-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j+nn),7)*10^(-3)))+floor((w-n21*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j+nn),7)*10^(-3)));
            
            n2=n2+n21;
            fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+nn),5))*n2;%������
            fadian(k,m+3)=fadian(k,m)+biao3(diyiz(i,j),5)*n22; %������2
            fadian(k,m+3+3)=fadian(k,m)+biao3(diyiz(i,j+nn),5)*n222;%������3

            fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+nn),6))*n2;%��������
            fadian(k,m+1+3)=fadian(k,m+1)+biao3(diyiz(i,j),6)*n22;%��������2
            fadian(k,m+1+3+3)=fadian(k,m+1)+biao3(diyiz(i,j+nn),6)*n222;%��������3

            for l=1:n1(1,1)
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2) < nibian(l,1)
                    a1(p,1)=nibian(l,2);
                    p=p+1;
                end
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2+biao3(diyiz(i,j),2)*n22) < nibian(l,1)
                    a2(p1,1)=nibian(l,2);
                    p1=p1+1;
                end
                if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2+biao3(diyiz(i,j+nn),2)*n222) < nibian(l,1)
                    a3(p2,1)=nibian(l,2);
                    p2=p2+1;
                end
            end
            fadian(k,m+2)=min(a1);%���������
            fadian(k,m+2+3)=min(a2);%���������
            fadian(k,m+2+3+3)=min(a3);%���������
            k=k+1;
        end
        k=k+1;
end
% i=6;%�����ַ���
% m=1;p=1;p1=1;p2=1;
% for j=1:2
%         for nn=1:2-j
%             n2=floor(3.35751/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))));
%             n21=floor(1.77032/((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))));
%             n22=floor((3.35751-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j),7)*10^(-3)))+floor((1.77032-n21*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j),7)*10^(-3)));
%             n222=floor((3.35751-n2*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j+nn),7)*10^(-3)))+floor((1.77032-n21*((biao3(diyiz(i,j),7)*10^(-3))+(biao3(diyiz(i,j+nn),7)*10^(-3))))/(biao3(diyiz(i,j+nn),7)*10^(-3)));
%             
%             n2=n2+n21;
%             fadian(k,m)=(biao3(diyiz(i,j),5)+biao3(diyiz(i,j+nn),5))*n2;%������
%             fadian(k,m+3)=fadian(k,m)+biao3(diyiz(i,j),5)*n22; %������2
%             fadian(k,m+3+3)=fadian(k,m)+biao3(diyiz(i,j+nn),5)*n222;%������3
% 
%             fadian(k,m+1)=(biao3(diyiz(i,j),6)+biao3(diyiz(i,j+nn),6))*n2;%��������
%             fadian(k,m+1+3)=fadian(k,m+1)+biao3(diyiz(i,j),6)*n22;%��������2
%             fadian(k,m+1+3+3)=fadian(k,m+1)+biao3(diyiz(i,j+nn),6)*n222;%��������3
% 
%             for l=1:n1(1,1)
%                 if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2) < nibian(l,1)
%                     a1(p,1)=nibian(l,2);
%                     p=p+1;
%                 end
%                 if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2+biao3(diyiz(i,j),2)*n22) < nibian(l,1)
%                     a2(p1,1)=nibian(l,2);
%                     p1=p1+1;
%                 end
%                 if ((biao3(diyiz(i,j),2)+biao3(diyiz(i,j+nn),2))*n2+biao3(diyiz(i,j+nn),2)*n222) < nibian(l,1)
%                     a3(p2,1)=nibian(l,2);
%                     p2=p2+1;
%                 end
%             end
%             fadian(k,m+2)=min(a1);%���������
%             fadian(k,m+2+3)=min(a2);%���������
%             fadian(k,m+2+3+3)=min(a3);%���������
%             k=k+1;
%         end
%         k=k+1;
% end

n=size(fadian);
k=1;
for i=1:n(1,1)
    for j=1:n(1,2)
        if j==1
            a(k,1)=fadian(i,j);
        end
        if j==2
            a(k,2)=fadian(i,j);
        end
        if j==3
            a(k,3)=fadian(i,j);
        end
        if j==4
            a(k+1,1)=fadian(i,j);
        end
        if j==5
            a(k+1,2)=fadian(i,j);
        end
        if j==6
            a(k+1,3)=fadian(i,j);
        end
        if j==7
            a(k+2,1)=fadian(i,j);
         end
        if j==8
            a(k+2,2)=fadian(i,j); 
        end
        if j==9
            a(k+2,3)=fadian(i,j);
        end 
    end
    k=k+3;
end

        
        
        
        
        
        
        
        

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')