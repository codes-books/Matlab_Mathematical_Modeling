clc,clear
load sanchuan.mat
n=size(sanchuan);
k=1;
for i=1:n(1,1)
    for j=1:n(1,2)
        if j==1
            a(k,1)=sanchuan(i,j);
        end
        if j==2
            a(k,2)=sanchuan(i,j);
        end
        if j==3
            a(k,3)=sanchuan(i,j);
        end
        if j==4
            a(k+1,1)=sanchuan(i,j);
        end
        if j==5
            a(k+1,2)=sanchuan(i,j);
        end
        if j==6
            a(k+1,3)=sanchuan(i,j);
        end
        if j==7
            a(k+2,1)=sanchuan(i,j);
         end
        if j==8
            a(k+2,2)=sanchuan(i,j); 
        end
        if j==9
            a(k+2,3)=sanchuan(i,j);
        end 
        if j==10
            a(k+3,1)=sanchuan(i,j);
         end
        if j==11
            a(k+3,2)=sanchuan(i,j); 
        end
        if j==12
            a(k+3,3)=sanchuan(i,j);
        end 
    end
    k=k+4;
end

 web('http://www.ilovematlab.cn/forum-238-1.html','-browser')